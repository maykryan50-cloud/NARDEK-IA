# google-services.json — onde este arquivo precisa ficar

## Situação atual

Este arquivo **não está no projeto** de propósito, por dois motivos:

1. **Ele é seu, não do repositório.** Contém os identificadores do seu projeto
   Firebase (`nardek-ia`) e a chave pública do app Android. Em repositório
   **público** isso não deve ficar versionado.
2. **Ele ainda não é necessário.** O plugin do Firebase só é aplicado na
   **etapa V3** (login com Google). Nas versões V1/V2, o app compila
   normalmente sem ele.

## Onde ele deve ficar (quando chegar a V3)

Caminho exato exigido pelo plugin do Firebase:

```
NARDEK_IA/
└── app/
    └── google-services.json      ← aqui
```

## Como obter o arquivo

1. Abra `https://console.firebase.google.com/` e entre no projeto **nardek-ia**
2. Ícone de engrenagem ⚙️ → **Configurações do projeto**
3. Aba **Geral** → role até **Seus apps** → app Android `com.nexia.app`
4. Clique em **GoogleServices-Info.plist / google-services.json** → baixe o
   **google-services.json**
5. Renomeie/coloque como `app/google-services.json` (mantendo esse nome exato)

> **Importante:** se você adicionar o SHA-1 no Firebase depois, baixe o arquivo
> **de novo** — ele muda.

## Como ativar o Firebase no build

No arquivo `app/build.gradle.kts`, dentro de `plugins { ... }`, descomente:

```kotlin
id("com.google.gms.google-services") version "4.4.2"
```

E no `build.gradle.kts` **da raiz**:

```kotlin
id("com.google.gms.google-services") version "4.4.2" apply false
```

Depois descomente as dependências do Firebase no fim do `app/build.gradle.kts`.

## Como usar no GitHub Actions sem deixar o arquivo público

O arquivo é restaurado em tempo de execução, a partir de um **Secret**:

1. Converta o arquivo para texto base64 no seu computador:
   * Linux/macOS: `base64 -w0 app/google-services.json > gs64.txt`
   * Windows (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("app\google-services.json")) > gs64.txt`
2. No GitHub: **Settings → Secrets and variables → Actions → New repository secret**
   * Nome: `GOOGLE_SERVICES_JSON_B64`
   * Valor: o conteúdo do `gs64.txt`
3. No workflow, descomente o passo que já está preparado no arquivo
   `.github/workflows/apk.yml` (procure por "Firebase (V3)").

Assim o arquivo aparece só durante a compilação, e nunca fica gravado no
repositório.
