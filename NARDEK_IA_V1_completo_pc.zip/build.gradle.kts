// Build script raiz da NARDEK IA
// Aqui só declaramos os plugins; eles são aplicados de fato no módulo :app
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
