#!/usr/bin/env python3
"""
Verificação do esqueleto da NARDEK IA — sem compilar.

Confere, em segundos e com pouca memória:
  1. pastas obrigatórias do Android e do backend;
  2. todo R.string.X / R.drawable.X usado no Kotlin existe nos recursos;
  3. todo pacote declarado no Kotlin bate com a pasta do arquivo;
  4. todos os arquivos Python do backend compilam (sintaxe).

Uso:  python3 scripts/verificar_esqueleto.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
APP = RAIZ / "app" / "src" / "main"
JAVA = APP / "java" / "com" / "nexia" / "app"
RES = APP / "res"
BACKEND = RAIZ / "backend"

PASTAS_ANDROID = [
    "ui/screens", "ui/components", "ui/theme", "ui/navigation",
    "data/local", "data/remote", "data/repository",
    "domain/model", "auth", "chat", "lab", "memory", "settings", "admin",
]
PASTAS_BACKEND = ["api", "auth", "chat", "lab", "memory", "admin", "models", "services", "tests"]

erros: list[str] = []
avisos: list[str] = []


def checar_pastas() -> None:
    for pasta in PASTAS_ANDROID:
        if not (JAVA / pasta).is_dir():
            erros.append(f"Android: pasta ausente → {pasta}")
    for pasta in PASTAS_BACKEND:
        if not (BACKEND / pasta).is_dir():
            erros.append(f"Backend: pasta ausente → {pasta}")
    if not (BACKEND / "main.py").is_file():
        erros.append("Backend: main.py ausente")


def recursos_disponiveis() -> tuple[set[str], set[str]]:
    strings: set[str] = set()
    drawables: set[str] = set()

    for xml in (RES / "values" / "strings.xml",):
        if xml.is_file():
            strings |= set(re.findall(r'<string name="([^"]+)"', xml.read_text(encoding="utf-8")))

    # idiomas extras não precisam repetir todas as chaves, mas avisamos
    for variante in ("values-en", "values-es"):
        arq = RES / variante / "strings.xml"
        if arq.is_file():
            chaves = set(re.findall(r'<string name="([^"]+)"', arq.read_text(encoding="utf-8")))
            faltando = strings - chaves - {"app_name"}
            if faltando:
                avisos.append(f"{variante}: {len(faltando)} chave(s) sem tradução (usa o padrão)")

    for pasta in RES.iterdir():
        if not pasta.is_dir():
            continue
        for arquivo in pasta.iterdir():
            if arquivo.suffix in {".xml", ".png", ".webp", ".jpg"}:
                drawables.add(arquivo.stem)
    return strings, drawables


def checar_referencias(strings: set[str], drawables: set[str]) -> None:
    padrao = re.compile(r"R\.(string|drawable|mipmap)\.([A-Za-z0-9_]+)")
    for kt in sorted(JAVA.rglob("*.kt")):
        texto = kt.read_text(encoding="utf-8")
        for tipo, nome in padrao.findall(texto):
            if tipo == "string" and nome not in strings:
                erros.append(f"{kt.relative_to(RAIZ)}: R.string.{nome} não existe")
            if tipo in {"drawable", "mipmap"} and nome not in drawables:
                erros.append(f"{kt.relative_to(RAIZ)}: R.{tipo}.{nome} não existe")


def checar_pacotes() -> None:
    """O `package` declarado no arquivo precisa apontar para a própria pasta."""
    for kt in sorted(JAVA.rglob("*.kt")):
        texto = kt.read_text(encoding="utf-8")
        achado = re.search(r"^package\s+([\w.]+)", texto, re.MULTILINE)
        if not achado:
            erros.append(f"{kt.relative_to(RAIZ)}: sem declaração de package")
            continue
        sufixo = str(kt.parent.relative_to(JAVA)).replace("\\", "/").strip("/")
        sufixo = "" if sufixo in {"", "."} else "." + sufixo.replace("/", ".")
        esperado = "com.nexia.app" + sufixo
        if achado.group(1) != esperado:
            erros.append(f"{kt.relative_to(RAIZ)}: package '{achado.group(1)}' deveria ser '{esperado}'")


def checar_python() -> None:
    import py_compile

    for py in sorted(BACKEND.rglob("*.py")):
        if "__pycache__" in str(py):
            continue
        try:
            py_compile.compile(str(py), doraise=True, cfile=str(py) + ".check")
        except py_compile.PyCompileError as erro:
            erros.append(f"{py.relative_to(RAIZ)}: erro de sintaxe → {erro.msg}")
        finally:
            Path(str(py) + ".check").unlink(missing_ok=True)


def main() -> int:
    checar_pastas()
    strings, drawables = recursos_disponiveis()
    checar_referencias(strings, drawables)
    checar_pacotes()
    checar_python()

    total_kt = len(list(JAVA.rglob("*.kt")))
    total_py = len([p for p in BACKEND.rglob("*.py") if "__pycache__" not in str(p)])

    print("=" * 60)
    print(" NARDEK IA — verificação do esqueleto")
    print("=" * 60)
    print(f" Kotlin: {total_kt} arquivos · Strings: {len(strings)} · Recursos: {len(drawables)}")
    print(f" Python: {total_py} arquivos")
    print("-" * 60)

    for aviso in avisos:
        print(f" [aviso] {aviso}")
    for erro in erros:
        print(f" [ERRO ] {erro}")

    if not erros:
        print(" Resultado: esqueleto consistente ✔ (nenhum erro estrutural)")
        return 0
    print(f" Resultado: {len(erros)} erro(s) encontrados ✘")
    return 1


if __name__ == "__main__":
    sys.exit(main())
