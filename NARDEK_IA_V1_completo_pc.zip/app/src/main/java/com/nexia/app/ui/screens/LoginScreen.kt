package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.nexia.app.BuildConfig
import com.nexia.app.R
import com.nexia.app.ui.components.NardekBrandBlock
import com.nexia.app.ui.theme.NardekPalette
import com.nexia.app.ui.theme.LocalNardekColors

/**
 * Tela de login.
 *
 * Já está preparada para o Google Sign-In (o Web Client ID público está em
 * BuildConfig), mas o botão do Google só passa a funcionar na V3, quando
 * existirem as bibliotecas do Firebase no app E o SHA-1 do certificado de
 * assinatura cadastrado no projeto — sem isso o Google recusa o app.
 *
 * O login ativo nesta versão conversa com o backend (desenvolvimento) e o
 * PAPEL do usuário é decidido pelo servidor, nunca por esta tela.
 */
@Composable
fun LoginScreen(
    isLoading: Boolean,
    error: String?,
    onSignIn: (email: String, displayName: String) -> Unit,
    onContinueOffline: () -> Unit,
    onGoogleClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        NardekBrandBlock(symbolSize = 104.dp)
        Spacer(Modifier.height(28.dp))

        Text(
            text = stringResource(id = R.string.login_title),
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(id = R.string.login_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textMuted,
        )

        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(id = R.string.login_email)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(id = R.string.login_name)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { onSignIn(email, name) },
            enabled = !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = NardekPalette.Blue,
                contentColor = androidx.compose.ui.graphics.Color.White,
            ),
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                Text(stringResource(id = R.string.login_continue))
            }
        }

        Spacer(Modifier.height(10.dp))

        OutlinedButton(
            onClick = onGoogleClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
        ) {
            Text(stringResource(id = R.string.login_google))
        }

        if (error != null) {
            Spacer(Modifier.height(12.dp))
            InfoCard(text = error, isError = true)
        }

        Spacer(Modifier.height(16.dp))

        InfoCard(
            icon = Icons.Filled.Lock,
            title = stringResource(id = R.string.login_security_title),
            text = stringResource(id = R.string.login_security_body),
        )

        Spacer(Modifier.height(10.dp))

        InfoCard(
            title = stringResource(id = R.string.login_google_pending_title),
            text = stringResource(
                id = R.string.login_google_pending_body,
                BuildConfig.GOOGLE_WEB_CLIENT_ID.take(24) + "…",
            ),
        )

        Spacer(Modifier.height(16.dp))

        OutlinedButton(onClick = onContinueOffline, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(id = R.string.login_offline))
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoCard(
    text: String,
    isError: Boolean = false,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    title: String? = null,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (isError) NardekPalette.ErrorContainer else colors.surfaceHigh,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (isError) NardekPalette.Error.copy(alpha = 0.5f) else colors.outline,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            if (title != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = NardekPalette.Cyan,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.size(8.dp))
                    }
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = if (isError) NardekPalette.Error else colors.textSecondary,
            )
        }
    }
}
