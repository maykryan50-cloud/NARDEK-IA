package com.nexia.app.data.repository

import com.nexia.app.data.remote.NardekBackend
import com.nexia.app.domain.model.ChatMessage
import com.nexia.app.domain.model.ChatRole
import com.nexia.app.domain.model.UsageLimits
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** O que o chat devolve para a tela. */
sealed interface ChatOutcome {
    data class Success(
        val reply: String,
        val language: String,
        val modelName: String,
        val limits: UsageLimits?,
    ) : ChatOutcome

    data class Failure(
        val message: String,
        val hint: String? = null,
    ) : ChatOutcome
}

/** Contrato do chat: a tela não sabe (e não precisa saber) de onde vem a resposta. */
interface ChatRepository {
    suspend fun send(
        prompt: String,
        history: List<ChatMessage>,
        modelId: String,
        responseLanguage: String,
        conversationId: String,
    ): ChatOutcome
}

/**
 * Repositório online: conversa com o backend FastAPI, que é quem fala com a IA.
 * Envia o token da sessão e recebe a resposta, o idioma usado e os limites atuais.
 */
class BackendChatRepository(
    private val backend: NardekBackend,
    private val tokenProvider: () -> String?,
) : ChatRepository {

    override suspend fun send(
        prompt: String,
        history: List<ChatMessage>,
        modelId: String,
        responseLanguage: String,
        conversationId: String,
    ): ChatOutcome = withContext(Dispatchers.IO) {
        val historyJson = JSONArray().apply {
            history.takeLast(20).forEach { message ->
                put(
                    JSONObject()
                        .put("role", if (message.role == ChatRole.USER) "user" else "assistant")
                        .put("content", message.text),
                )
            }
        }

        val payload = JSONObject()
            .put("message", prompt)
            .put("conversation_id", conversationId)
            .put("model", modelId)
            .put("response_language", responseLanguage)
            .put("history", historyJson)
            .toString()

        val result = backend.post("/api/v1/chat", payload, tokenProvider())
        if (result.networkError != null) {
            return@withContext ChatOutcome.Failure(
                message = "Não consegui falar com o backend da NARDEK.",
                hint = "Verifique se o servidor está no ar e se a URL em " +
                    "NARDEK_BACKEND_URL está correta (${backend.baseUrl}). Detalhe: ${result.networkError}",
            )
        }

        val json = runCatching { JSONObject(result.body) }.getOrNull()
        if (!result.isOk || json == null) {
            val detail = json?.optString("detail").orEmpty().ifBlank { result.body.take(200) }
            return@withContext ChatOutcome.Failure(
                message = detail.ifBlank { "O servidor respondeu ${result.statusCode}." },
                hint = when (result.statusCode) {
                    401 -> "Sua sessão expirou. Entre novamente."
                    429 -> "Limite diário atingido. O contador zera à meia-noite (UTC)."
                    403 -> "Seu papel não permite este modelo."
                    else -> null
                },
            )
        }

        val usage = json.optJSONObject("limits")
        ChatOutcome.Success(
            reply = json.optString("reply"),
            language = json.optString("language", "pt-BR"),
            modelName = json.optString("model_name", modelId),
            limits = usage?.let {
                UsageLimits(
                    dailyMessagesUsed = it.optInt("daily_messages_used"),
                    dailyMessagesLimit = it.optInt("daily_messages_limit"),
                    dailyCostUsedUsd = it.optDouble("daily_cost_used_usd", 0.0),
                    dailyCostLimitUsd = it.optDouble("daily_cost_limit_usd", 0.0),
                )
            },
        )
    }
}

/**
 * Repositório local (modo offline/demonstração).
 * Responde sem internet — usado quando o usuário ainda não entrou na conta
 * ou quando o backend não está acessível.
 */
class LocalChatRepository : ChatRepository {

    override suspend fun send(
        prompt: String,
        history: List<ChatMessage>,
        modelId: String,
        responseLanguage: String,
        conversationId: String,
    ): ChatOutcome {
        delay(180) // simula o tempo de rede para a interface se comportar de verdade
        val text = when {
            prompt.contains("quem é você", true) || prompt.contains("seu nome", true) ->
                "Sou a NARDEK IA. Estou respondendo pelo modo local do aplicativo, " +
                    "sem internet e sem custo. Ao entrar na sua conta, minhas respostas " +
                    "passam a vir do backend com o modelo de verdade."

            prompt.contains("backend", true) || prompt.contains("servidor", true) ->
                "O backend da NARDEK é um servidor Python/FastAPI. Ele guarda a chave do " +
                    "provedor de IA e valida as permissões — por isso nada de sensível fica no APK."

            else ->
                "Recebi sua mensagem: \"$prompt\".\n\n" +
                    "Estou no modo local (V1 offline). Entre na sua conta para conversar " +
                    "com o modelo escolhido no servidor: ${reportLanguage(responseLanguage)}."
        }
        return ChatOutcome.Success(
            reply = text,
            language = if (responseLanguage == "auto") "pt-BR" else responseLanguage,
            modelName = modelId,
            limits = null,
        )
    }

    private fun reportLanguage(responseLanguage: String): String =
        if (responseLanguage == "auto") "automático, no idioma da sua mensagem" else responseLanguage
}
