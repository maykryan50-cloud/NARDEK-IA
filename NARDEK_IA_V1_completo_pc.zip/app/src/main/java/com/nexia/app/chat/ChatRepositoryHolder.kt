package com.nexia.app.chat

import com.nexia.app.data.remote.NardekBackend
import com.nexia.app.data.repository.BackendChatRepository
import com.nexia.app.data.repository.ChatRepository
import com.nexia.app.data.repository.LocalChatRepository

/**
 * Escolhe a origem das respostas:
 *
 *   * usuário com sessão iniciada  → backend (IA real do servidor);
 *   * usuário sem sessão / offline → motor local de demonstração.
 *
 * A tela de chat não muda: ela conversa sempre com a interface [ChatRepository].
 */
class ChatRepositoryHolder(
    backend: NardekBackend,
    private val tokenProvider: () -> String?,
) {
    private val online: ChatRepository = BackendChatRepository(backend, tokenProvider)
    private val offline: ChatRepository = LocalChatRepository()

    val isOnlineAvailable: Boolean get() = !tokenProvider().isNullOrBlank()

    fun current(): ChatRepository = if (isOnlineAvailable) online else offline
}
