package com.nexia.app.data.local

import android.content.Context
import android.content.SharedPreferences
import com.nexia.app.domain.model.InterfaceLanguage
import com.nexia.app.domain.model.ResponseLanguage
import com.nexia.app.domain.model.ThemeMode

/**
 * Preferências locais da NARDEK IA.
 *
 * Guarda apenas o que é do aparelho: tema, idiomas escolhidos, modelo preferido
 * e o token da sessão. Nenhuma chave de API passa por aqui.
 */
class NardekPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("nardek_prefs", Context.MODE_PRIVATE)

    // --- Tema ---------------------------------------------------------
    var themeMode: ThemeMode
        get() = ThemeMode.fromId(prefs.getString(KEY_THEME, ThemeMode.DARK.id))
        set(value) = prefs.edit().putString(KEY_THEME, value.id).apply()

    // --- Idiomas ------------------------------------------------------
    /** Idioma da interface gráfica do aplicativo. */
    var interfaceLanguage: InterfaceLanguage
        get() = InterfaceLanguage.fromCode(prefs.getString(KEY_INTERFACE_LANGUAGE, null))
        set(value) = prefs.edit().putString(KEY_INTERFACE_LANGUAGE, value.code).apply()

    /** Idioma das respostas da IA ("auto" = mesmo idioma da mensagem). */
    var responseLanguage: ResponseLanguage
        get() = ResponseLanguage.fromCode(prefs.getString(KEY_RESPONSE_LANGUAGE, ResponseLanguage.AUTO.code))
        set(value) = prefs.edit().putString(KEY_RESPONSE_LANGUAGE, value.code).apply()

    /** Se verdadeiro, a IA acompanha o idioma da mensagem recebida. */
    var aiFollowsMessageLanguage: Boolean
        get() = prefs.getBoolean(KEY_AI_FOLLOWS, true)
        set(value) = prefs.edit().putBoolean(KEY_AI_FOLLOWS, value).apply()

    // --- Chat ---------------------------------------------------------
    var selectedModelId: String
        get() = prefs.getString(KEY_MODEL, "nardek") ?: "nardek"
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    var streamingEnabled: Boolean
        get() = prefs.getBoolean(KEY_STREAMING, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAMING, value).apply()

    // --- Sessão -------------------------------------------------------
    var authToken: String?
        get() = prefs.getString(KEY_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    var authUid: String?
        get() = prefs.getString(KEY_UID, null)
        set(value) = prefs.edit().putString(KEY_UID, value).apply()

    var authEmail: String?
        get() = prefs.getString(KEY_EMAIL, null)
        set(value) = prefs.edit().putString(KEY_EMAIL, value).apply()

    var authDisplayName: String?
        get() = prefs.getString(KEY_NAME, null)
        set(value) = prefs.edit().putString(KEY_NAME, value).apply()

    var authRole: String?
        get() = prefs.getString(KEY_ROLE, null)
        set(value) = prefs.edit().putString(KEY_ROLE, value).apply()

    val isSignedIn: Boolean get() = !authToken.isNullOrBlank()

    fun saveSession(token: String, uid: String, email: String?, displayName: String, role: String) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_UID, uid)
            .putString(KEY_EMAIL, email)
            .putString(KEY_NAME, displayName)
            .putString(KEY_ROLE, role)
            .apply()
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_TOKEN).remove(KEY_UID).remove(KEY_EMAIL)
            .remove(KEY_NAME).remove(KEY_ROLE)
            .apply()
    }

    private companion object {
        const val KEY_THEME = "theme_mode"
        const val KEY_INTERFACE_LANGUAGE = "interface_language"
        const val KEY_RESPONSE_LANGUAGE = "response_language"
        const val KEY_AI_FOLLOWS = "ai_follows_message_language"
        const val KEY_MODEL = "selected_model"
        const val KEY_STREAMING = "streaming_enabled"
        const val KEY_TOKEN = "auth_token"
        const val KEY_UID = "auth_uid"
        const val KEY_EMAIL = "auth_email"
        const val KEY_NAME = "auth_name"
        const val KEY_ROLE = "auth_role"
    }
}
