package com.nexia.app.auth

import com.nexia.app.data.local.NardekPreferences
import com.nexia.app.data.remote.NardekBackend
import com.nexia.app.domain.model.Identity
import com.nexia.app.domain.model.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Resultado de uma tentativa de entrar. */
sealed interface AuthResult {
    data class Success(val identity: Identity) : AuthResult
    data class Failure(val message: String) : AuthResult
}

/**
 * Contrato de autenticação.
 *
 * O aplicativo apenas ENVIA a credencial; quem decide o papel (USER/ADMIN/OWNER)
 * é o servidor, em /api/v1/me. O app nunca deduz permissão sozinho.
 */
interface AuthRepository {
    suspend fun signIn(email: String, displayName: String): AuthResult
    suspend fun refreshIdentity(): AuthResult?
    fun signedIdentity(): Identity?
    fun signOut()
}

/**
 * Implementação usada enquanto o Firebase Authentication não está ligado.
 *
 * Usa o endpoint de desenvolvimento do backend (/api/v1/auth/dev-login), que
 * existe apenas quando o servidor roda com AUTH_MODE=dev. Em produção, o
 * backend responde 404 e o caminho passa a ser o Google Sign-In (V3).
 */
class AuthRepositoryImpl(
    private val backend: NardekBackend,
    private val preferences: NardekPreferences,
) : AuthRepository {

    override suspend fun signIn(email: String, displayName: String): AuthResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("email", email.trim())
                .put("display_name", displayName.trim().ifBlank { email.substringBefore("@") })
                .toString()

            val result = backend.post("/api/v1/auth/dev-login", body)
            if (result.networkError != null) {
                return@withContext AuthResult.Failure(
                    "Sem conexão com o backend (${backend.baseUrl}). " +
                        "Detalhe: ${result.networkError}",
                )
            }
            val json = runCatching { JSONObject(result.body) }.getOrNull()
            if (!result.isOk || json == null) {
                val detail = json?.optString("detail").orEmpty()
                return@withContext AuthResult.Failure(
                    detail.ifBlank { "O servidor recusou o acesso (HTTP ${result.statusCode})." },
                )
            }

            val token = json.optString("access_token")
            val uid = json.optString("uid")
            val role = Role.fromId(json.optString("role"))
            val name = displayName.trim().ifBlank { email.substringBefore("@") }

            preferences.saveSession(
                token = token,
                uid = uid,
                email = json.optString("email").ifBlank { email },
                displayName = name,
                role = role.id,
            )

            AuthResult.Success(
                Identity(
                    uid = uid,
                    email = json.optString("email"),
                    displayName = name,
                    role = role,
                    godMode = role.canSeeGodMode,
                ),
            )
        }

    /** Pergunta ao servidor quem eu sou agora (papel pode ter mudado). */
    override suspend fun refreshIdentity(): AuthResult? = withContext(Dispatchers.IO) {
        val token = preferences.authToken ?: return@withContext null
        val result = backend.get("/api/v1/me", token)
        val json = runCatching { JSONObject(result.body) }.getOrNull()
        if (!result.isOk || json == null) {
            if (result.statusCode == 401) preferences.clearSession()
            return@withContext null
        }

        val role = Role.fromId(json.optString("role"))
        val identity = Identity(
            uid = json.optString("uid"),
            email = json.optString("email").ifBlank { null },
            displayName = json.optString("display_name"),
            role = role,
            permissions = json.optJSONArray("permissions")?.let { array ->
                List(array.length()) { index -> array.optString(index) }
            } ?: emptyList(),
            godMode = json.optBoolean("god_mode", role.canSeeGodMode),
        )
        preferences.authRole = role.id
        AuthResult.Success(identity)
    }

    override fun signedIdentity(): Identity? {
        val token = preferences.authToken ?: return null
        if (token.isBlank()) return null
        val role = Role.fromId(preferences.authRole)
        return Identity(
            uid = preferences.authUid.orEmpty(),
            email = preferences.authEmail,
            displayName = preferences.authDisplayName ?: "Convidado",
            role = role,
            godMode = role.canSeeGodMode,
        )
    }

    override fun signOut() = preferences.clearSession()
}

/**
 * Google Sign-In (V3) — a estrutura já está pronta, mas o login não pode ser
 * ativado antes de dois itens que dependem do Firebase:
 *
 *   1. bibliotecas do Firebase Auth + Credential Manager no app;
 *   2. SHA-1 do certificado de assinatura cadastrado no Firebase (sem ele o
 *      Google recusa o app, e não se inventa um SHA-1).
 *
 * O Web Client ID (público) já está em BuildConfig.GOOGLE_WEB_CLIENT_ID.
 */
class PendingGoogleSignIn(private val webClientId: String) : AuthRepository {

    override suspend fun signIn(email: String, displayName: String): AuthResult =
        AuthResult.Failure(
            "O login com Google entra na etapa V3 (Firebase + SHA-1). " +
                "Web Client ID já configurado: $webClientId",
        )

    override suspend fun refreshIdentity(): AuthResult? = null

    override fun signedIdentity(): Identity? = null

    override fun signOut() = Unit
}
