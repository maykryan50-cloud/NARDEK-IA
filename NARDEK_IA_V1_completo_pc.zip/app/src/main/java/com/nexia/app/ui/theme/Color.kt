package com.nexia.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Paleta oficial da NARDEK IA — extraída da logomarca:
 * azul #014FF2 (marca) e ciano #0AC2FD (brilho da fita do símbolo N).
 */
object NardekPalette {
    // Marca
    val Cyan = Color(0xFF0AC2FD)
    val CyanBright = Color(0xFF7DEBFF)
    val CyanDeep = Color(0xFF0891C4)
    val Blue = Color(0xFF014FF2)
    val BlueDeep = Color(0xFF0136C9)

    // Tema escuro
    val DarkBackground = Color(0xFF070B14)
    val DarkBackgroundAlt = Color(0xFF0B1220)
    val DarkSurface = Color(0xFF101A2B)
    val DarkSurfaceHigh = Color(0xFF16233A)
    val DarkOutline = Color(0xFF22314B)
    val DarkTextPrimary = Color(0xFFF2F7FF)
    val DarkTextSecondary = Color(0xFF9AA9C2)
    val DarkTextMuted = Color(0xFF6C7A93)
    val DarkUserBubble = Color(0xFF12365C)
    val DarkAssistantBubble = Color(0xFF111C2E)

    // Tema claro
    val LightBackground = Color(0xFFF6F8FD)
    val LightBackgroundAlt = Color(0xFFFFFFFF)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceHigh = Color(0xFFEDF2FB)
    val LightOutline = Color(0xFFD3DCEA)
    val LightTextPrimary = Color(0xFF0B1526)
    val LightTextSecondary = Color(0xFF4A5A75)
    val LightTextMuted = Color(0xFF7C8AA3)
    val LightUserBubble = Color(0xFFDCE9FF)
    val LightAssistantBubble = Color(0xFFF1F5FC)

    // Estados
    val Error = Color(0xFFFF5C5C)
    val ErrorContainer = Color(0xFF33161C)
    val Success = Color(0xFF2ECC8F)
    val Warning = Color(0xFFFFB020)

    /** Gradiente da marca: ciano → azul (usado no botão enviar, avatar e destaques). */
    val BrandGradient = Brush.linearGradient(listOf(Cyan, Blue))
    val BrandGradientSoft = Brush.linearGradient(listOf(CyanBright, Blue))
}
