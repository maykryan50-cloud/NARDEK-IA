package com.nexia.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.nexia.app.data.AppContainer
import com.nexia.app.ui.NardekRoot

/** Única Activity da NARDEK IA. Toda a interface é Jetpack Compose. */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Prepara as dependências (preferências, backend, repositórios) antes da interface.
        AppContainer.init(applicationContext)

        enableEdgeToEdge()
        setContent { NardekRoot() }
    }
}
