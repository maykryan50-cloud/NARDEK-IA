package com.nexia.app.ui.components

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.nexia.app.domain.model.InterfaceLanguage
import java.util.Locale

/**
 * Sistema de idiomas do aplicativo.
 *
 * Envolve a interface com um contexto configurado no idioma escolhido pelo
 * usuário, então `stringResource(...)` passa a devolver o texto traduzido
 * (res/values, res/values-en, res/values-es) sem reiniciar o aplicativo.
 *
 * Observação: isto cuida do IDIOMA DA INTERFACE. O idioma das RESPOSTAS da IA
 * é outro: vai em cada requisição de chat como `response_language`.
 */
@Composable
fun NardekLocaleProvider(
    language: InterfaceLanguage,
    content: @Composable () -> Unit,
) {
    if (language == InterfaceLanguage.SYSTEM) {
        content()
        return
    }

    val context = LocalContext.current
    val localizedContext = remember(language) {
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(Locale.forLanguageTag(language.code))
        context.createConfigurationContext(configuration)
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalConfiguration provides localizedContext.resources.configuration,
        content = content,
    )
}
