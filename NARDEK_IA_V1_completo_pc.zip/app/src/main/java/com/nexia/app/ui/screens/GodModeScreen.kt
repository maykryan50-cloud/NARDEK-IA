package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.admin.AdminRepository
import com.nexia.app.admin.AdminUiState
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Modo Deus 👑
 *
 * Esta tela só é aberta por quem o SERVIDOR identificou como OWNER/ADMIN
 * (resposta de /api/v1/me). Todas as ações chamam o backend e ele revalida a
 * permissão: um usuário comum que forçar esta tela recebe 403 em cada operação.
 */
@Composable
fun GodModeScreen(
    state: AdminUiState,
    isOwner: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onKillSwitch: (Boolean) -> Unit,
    onChangeRole: (String, String) -> Unit,
    onToggleBlocked: (String, Boolean) -> Unit,
    onSetDailyLimit: (String, Int) -> Unit,
    onRunTool: (String) -> Unit,
    onMessageShown: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    var roleTarget by remember { mutableStateOf<AdminRepository.UserRow?>(null) }
    var limitTarget by remember { mutableStateOf<AdminRepository.UserRow?>(null) }

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.god_title),
            subtitle = state.overview?.let { "${it.environment} · ${it.myRole}" },
            onBackClick = onBack,
            trailing = {
                IconButton(onClick = onRefresh) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = stringResource(id = R.string.common_refresh),
                        tint = colors.textSecondary,
                    )
                }
            },
        )

        if (state.forbidden) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = NardekPalette.Error,
                    modifier = Modifier.size(42.dp),
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = stringResource(id = R.string.god_forbidden_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = state.error ?: stringResource(id = R.string.god_forbidden_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textMuted,
                )
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
        ) {
            // ---- Métricas ----
            item("overview") {
                val overview = state.overview
                if (overview != null) {
                    SectionTitle(stringResource(id = R.string.god_overview))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard(stringResource(id = R.string.god_users), overview.knownUsers.toString(), Modifier.weight(1f))
                        MetricCard(stringResource(id = R.string.god_messages_today), overview.messagesToday.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard(
                            stringResource(id = R.string.god_cost_today),
                            "US$ %.4f".format(overview.costTodayUsd),
                            Modifier.weight(1f),
                        )
                        MetricCard(
                            stringResource(id = R.string.god_budget),
                            "US$ %.2f".format(overview.budgetUsd),
                            Modifier.weight(1f),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    InfoRow(
                        label = stringResource(id = R.string.god_ai_provider),
                        value = "${overview.aiProvider} · " + stringResource(
                            id = if (overview.aiKeyConfigured) R.string.god_key_yes else R.string.god_key_no,
                        ),
                    )
                    Spacer(Modifier.height(16.dp))
                }
            }

            // ---- Interruptor geral ----
            item("killswitch") {
                SectionTitle(stringResource(id = R.string.god_kill_switch))
                Surface(
                    color = colors.surfaceHigh,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        1.dp,
                        if (state.overview?.killSwitch == true) NardekPalette.Error.copy(alpha = 0.6f) else colors.outline,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = if (state.overview?.killSwitch == true) NardekPalette.Error else colors.textMuted,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(id = R.string.god_kill_switch),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary,
                            )
                            Text(
                                text = stringResource(id = R.string.god_kill_switch_hint),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textMuted,
                            )
                        }
                        Switch(
                            checked = state.overview?.killSwitch == true,
                            enabled = isOwner,
                            onCheckedChange = onKillSwitch,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = NardekPalette.Error,
                                uncheckedTrackColor = colors.outline,
                            ),
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---- Usuários ----
            item("users-title") {
                SectionTitle(stringResource(id = R.string.god_users))
            }
            items(items = state.users, key = { it.uid }) { user ->
                UserCard(
                    user = user,
                    isOwner = isOwner,
                    onChangeRole = { roleTarget = user },
                    onToggleBlocked = { onToggleBlocked(user.uid, !user.blocked) },
                    onSetLimit = { limitTarget = user },
                )
                Spacer(Modifier.height(8.dp))
            }

            // ---- Ferramentas ----
            item("tools") {
                Spacer(Modifier.height(8.dp))
                SectionTitle(stringResource(id = R.string.god_tools))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onRunTool("ping") },
                        modifier = Modifier.weight(1f),
                    ) { Text(stringResource(id = R.string.god_tool_ping)) }
                    OutlinedButton(
                        onClick = { onRunTool("echo-models") },
                        modifier = Modifier.weight(1f),
                    ) { Text(stringResource(id = R.string.god_tool_models)) }
                }
                Spacer(Modifier.height(6.dp))
                if (isOwner) {
                    OutlinedButton(
                        onClick = { onRunTool("reset-usage") },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(id = R.string.god_tool_reset)) }
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---- Auditoria ----
            item("audit-title") {
                SectionTitle(stringResource(id = R.string.god_audit))
            }
            items(items = state.audit, key = { it.id }) { entry ->
                AuditCard(entry)
                Spacer(Modifier.height(6.dp))
            }
        }
    }

    // --- Diálogo: mudar papel ---
    roleTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { roleTarget = null },
            title = { Text(stringResource(id = R.string.god_change_role)) },
            text = {
                Column {
                    listOf("USER", "ADMIN", "OWNER").forEach { role ->
                        Text(
                            text = role + if (role == target.role) "  ✓" else "",
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (role == target.role) NardekPalette.Cyan else colors.textPrimary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onChangeRole(target.uid, role)
                                    roleTarget = null
                                }
                                .padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { roleTarget = null }) {
                    Text(stringResource(id = R.string.common_cancel), color = colors.textSecondary)
                }
            },
            containerColor = colors.surfaceHigh,
        )
    }

    // --- Diálogo: limite diário ---
    limitTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { limitTarget = null },
            title = { Text(stringResource(id = R.string.god_set_limit)) },
            text = {
                Column {
                    listOf(10, 50, 200, 1000, 10000).forEach { limit ->
                        Text(
                            text = "$limit",
                            style = MaterialTheme.typography.bodyLarge,
                            color = colors.textPrimary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSetDailyLimit(target.uid, limit)
                                    limitTarget = null
                                }
                                .padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { limitTarget = null }) {
                    Text(stringResource(id = R.string.common_cancel), color = colors.textSecondary)
                }
            },
            containerColor = colors.surfaceHigh,
        )
    }

    // --- Mensagens de retorno ----
    val message = state.error ?: state.lastAction
    if (message != null) {
        AlertDialog(
            onDismissRequest = onMessageShown,
            title = {
                Text(
                    text = if (state.error != null) {
                        stringResource(id = R.string.common_error)
                    } else {
                        stringResource(id = R.string.god_action_done)
                    },
                )
            },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = onMessageShown) { Text(stringResource(id = R.string.common_ok)) }
            },
            containerColor = colors.surfaceHigh,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = LocalNardekColors.current.textMuted,
        modifier = Modifier.padding(start = 2.dp, bottom = 8.dp),
    )
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = modifier,
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = NardekPalette.Cyan,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val colors = LocalNardekColors.current
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary,
        )
    }
}

@Composable
private fun UserCard(
    user: AdminRepository.UserRow,
    isOwner: Boolean,
    onChangeRole: () -> Unit,
    onToggleBlocked: () -> Unit,
    onSetLimit: () -> Unit,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (user.blocked) NardekPalette.Error.copy(alpha = 0.5f) else colors.outline,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = user.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                    )
                    Text(
                        text = (user.email ?: user.uid) + " · " + user.role,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textMuted,
                    )
                }
                Surface(
                    color = if (user.blocked) NardekPalette.Error.copy(alpha = 0.15f) else NardekPalette.Success.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(50),
                ) {
                    Text(
                        text = stringResource(
                            id = if (user.blocked) R.string.god_blocked else R.string.god_active,
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (user.blocked) NardekPalette.Error else NardekPalette.Success,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = stringResource(
                    id = R.string.god_user_usage,
                    user.messagesToday,
                    user.dailyMessageLimit ?: 0,
                    user.costTodayUsd,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
            )

            if (isOwner) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = onChangeRole, modifier = Modifier.weight(1f)) {
                        Text(stringResource(id = R.string.god_change_role), style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = onSetLimit, modifier = Modifier.weight(1f)) {
                        Text(stringResource(id = R.string.god_set_limit), style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = onToggleBlocked, modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(
                                id = if (user.blocked) R.string.god_unblock else R.string.god_block,
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (user.blocked) NardekPalette.Success else NardekPalette.Error,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditCard(entry: AdminRepository.AuditRow) {
    val colors = LocalNardekColors.current
    val formatter = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    Surface(
        color = colors.surfaceHigh.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = entry.action,
                style = MaterialTheme.typography.bodyMedium,
                color = NardekPalette.Cyan,
            )
            Text(
                text = "${entry.actor} · ${formatter.format(Date(entry.createdAt))}",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
            )
            if (entry.detail.isNotBlank()) {
                Text(
                    text = entry.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                )
            }
        }
    }
}
