package com.nexia.app.domain.model

import java.util.UUID

/** Quem escreveu a mensagem. */
enum class ChatRole { USER, ASSISTANT }

/** Uma mensagem da conversa. */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: ChatRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val language: String? = null,
)

/** Uma conversa. A V1 mantém em memória; a V4 guarda no aparelho. */
data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val preview: String
        get() = messages.lastOrNull()?.text ?: ""

    val isEmpty: Boolean get() = messages.isEmpty()
}

/** Modelo de IA mostrado no seletor (vem do backend, filtrado por papel). */
data class AiModel(
    val id: String,
    val name: String,
    val description: String,
    val isDefault: Boolean = false,
)
