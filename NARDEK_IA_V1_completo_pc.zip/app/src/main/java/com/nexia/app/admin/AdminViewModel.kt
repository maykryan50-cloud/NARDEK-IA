package com.nexia.app.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexia.app.data.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Estado do painel Modo Deus. */
data class AdminUiState(
    val isLoading: Boolean = false,
    val overview: AdminRepository.Overview? = null,
    val users: List<AdminRepository.UserRow> = emptyList(),
    val audit: List<AdminRepository.AuditRow> = emptyList(),
    val forbidden: Boolean = false,
    val error: String? = null,
    val lastAction: String? = null,
)

/**
 * Painel Modo Deus.
 *
 * Tudo o que esta ViewModel faz é chamar o backend. Se o usuário não for
 * OWNER/ADMIN, o servidor responde 403 e a tela mostra "acesso negado" —
 * mexer no aplicativo não muda isso.
 */
class AdminViewModel : ViewModel() {

    private val repository = AppContainer.adminRepository

    private val _state = MutableStateFlow(AdminUiState())
    val state: StateFlow<AdminUiState> = _state.asStateFlow()

    fun load() {
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val overview = repository.overview()
            if (overview.forbidden) {
                _state.update { it.copy(isLoading = false, forbidden = true, error = overview.error) }
                return@launch
            }
            val users = repository.users().data.orEmpty()
            val audit = repository.audit().data.orEmpty()
            _state.update {
                it.copy(
                    isLoading = false,
                    forbidden = false,
                    overview = overview.data,
                    users = users,
                    audit = audit,
                    error = overview.error,
                )
            }
        }
    }

    fun setKillSwitch(enabled: Boolean) = run("Interruptor geral ${if (enabled) "ligado" else "desligado"}") {
        repository.setKillSwitch(enabled).let { result ->
            if (result.isOk) null else result.error
        }
    }

    fun changeRole(uid: String, role: String) = run("Papel alterado para $role") {
        repository.updateUser(uid = uid, role = role).let { if (it.isOk) null else it.error }
    }

    fun setBlocked(uid: String, blocked: Boolean) = run(if (blocked) "Usuário bloqueado" else "Usuário liberado") {
        repository.updateUser(uid = uid, blocked = blocked).let { if (it.isOk) null else it.error }
    }

    fun setDailyLimit(uid: String, limit: Int) = run("Limite diário definido em $limit") {
        repository.updateUser(uid = uid, dailyMessageLimit = limit).let { if (it.isOk) null else it.error }
    }

    fun runTool(tool: String) = run("Ferramenta '$tool' executada") {
        val result = repository.runTool(tool)
        if (result.isOk) null else result.error
    }

    fun consumeMessage() = _state.update { it.copy(error = null, lastAction = null) }

    private fun run(successMessage: String, block: suspend () -> String?) {
        viewModelScope.launch {
            val error = block()
            _state.update { it.copy(error = error, lastAction = if (error == null) successMessage else null) }
            if (error == null) load()
        }
    }
}
