package com.nexia.app.domain.model

/**
 * Idioma da INTERFACE do aplicativo.
 * Controla apenas os textos do app (via strings.xml), não a IA.
 */
enum class InterfaceLanguage(val code: String, val flag: String, val nativeLabel: String) {
    SYSTEM("system", "📱", "Do sistema"),
    PT_BR("pt-BR", "🇧🇷", "Português (Brasil)"),
    EN_US("en-US", "🇺🇸", "English (US)"),
    ES_ES("es-ES", "🇪🇸", "Español");

    companion object {
        fun fromCode(code: String?): InterfaceLanguage = entries.firstOrNull { it.code == code } ?: SYSTEM
    }
}

/**
 * Idioma das RESPOSTAS da IA.
 * O valor [AUTO] é o "🌐 Responder sempre no idioma da mensagem": o servidor
 * detecta o idioma da mensagem enviada e responde no mesmo idioma.
 */
enum class ResponseLanguage(val code: String, val flag: String, val nativeLabel: String) {
    AUTO("auto", "🌐", "Responder no idioma da mensagem"),
    PT_BR("pt-BR", "🇧🇷", "Português (Brasil)"),
    EN_US("en-US", "🇺🇸", "English (US)"),
    ES_ES("es-ES", "🇪🇸", "Español"),
    FR_FR("fr-FR", "🇫🇷", "Français"),
    DE_DE("de-DE", "🇩🇪", "Deutsch"),
    IT_IT("it-IT", "🇮🇹", "Italiano"),
    JA_JP("ja-JP", "🇯🇵", "日本語"),
    ZH_CN("zh-CN", "🇨🇳", "中文");

    companion object {
        fun fromCode(code: String?): ResponseLanguage = entries.firstOrNull { it.code == code } ?: AUTO
    }
}
