package com.nexia.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.nexia.app.domain.model.ThemeMode

/** Cores extras que o Material3 não cobre (bolhas de chat, rodapé, etc.). */
data class NardekExtraColors(
    val backgroundAlt: Color,
    val surfaceHigh: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val userBubble: Color,
    val assistantBubble: Color,
    val outline: Color,
    val isDark: Boolean,
)

val LocalNardekColors = staticCompositionLocalOf {
    NardekExtraColors(
        backgroundAlt = NardekPalette.DarkBackgroundAlt,
        surfaceHigh = NardekPalette.DarkSurfaceHigh,
        textPrimary = NardekPalette.DarkTextPrimary,
        textSecondary = NardekPalette.DarkTextSecondary,
        textMuted = NardekPalette.DarkTextMuted,
        userBubble = NardekPalette.DarkUserBubble,
        assistantBubble = NardekPalette.DarkAssistantBubble,
        outline = NardekPalette.DarkOutline,
        isDark = true,
    )
}

private val DarkScheme = darkColorScheme(
    primary = NardekPalette.Cyan,
    onPrimary = Color(0xFF04121C),
    primaryContainer = NardekPalette.BlueDeep,
    onPrimaryContainer = NardekPalette.DarkTextPrimary,
    secondary = NardekPalette.Blue,
    onSecondary = Color.White,
    tertiary = NardekPalette.CyanDeep,
    background = NardekPalette.DarkBackground,
    onBackground = NardekPalette.DarkTextPrimary,
    surface = NardekPalette.DarkSurface,
    onSurface = NardekPalette.DarkTextPrimary,
    surfaceVariant = NardekPalette.DarkSurfaceHigh,
    onSurfaceVariant = NardekPalette.DarkTextSecondary,
    outline = NardekPalette.DarkOutline,
    error = NardekPalette.Error,
)

private val LightScheme = lightColorScheme(
    primary = NardekPalette.Blue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E4FF),
    onPrimaryContainer = NardekPalette.LightTextPrimary,
    secondary = NardekPalette.CyanDeep,
    onSecondary = Color.White,
    tertiary = NardekPalette.Cyan,
    background = NardekPalette.LightBackground,
    onBackground = NardekPalette.LightTextPrimary,
    surface = NardekPalette.LightSurface,
    onSurface = NardekPalette.LightTextPrimary,
    surfaceVariant = NardekPalette.LightSurfaceHigh,
    onSurfaceVariant = NardekPalette.LightTextSecondary,
    outline = NardekPalette.LightOutline,
    error = NardekPalette.Error,
)

/**
 * Tema da NARDEK IA com suporte nativo a Modo Claro e Modo Escuro.
 * O usuário escolhe em Configurações: Sistema, Claro ou Escuro.
 */
@Composable
fun NardekTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val extras = if (dark) {
        NardekExtraColors(
            backgroundAlt = NardekPalette.DarkBackgroundAlt,
            surfaceHigh = NardekPalette.DarkSurfaceHigh,
            textPrimary = NardekPalette.DarkTextPrimary,
            textSecondary = NardekPalette.DarkTextSecondary,
            textMuted = NardekPalette.DarkTextMuted,
            userBubble = NardekPalette.DarkUserBubble,
            assistantBubble = NardekPalette.DarkAssistantBubble,
            outline = NardekPalette.DarkOutline,
            isDark = true,
        )
    } else {
        NardekExtraColors(
            backgroundAlt = NardekPalette.LightBackgroundAlt,
            surfaceHigh = NardekPalette.LightSurfaceHigh,
            textPrimary = NardekPalette.LightTextPrimary,
            textSecondary = NardekPalette.LightTextSecondary,
            textMuted = NardekPalette.LightTextMuted,
            userBubble = NardekPalette.LightUserBubble,
            assistantBubble = NardekPalette.LightAssistantBubble,
            outline = NardekPalette.LightOutline,
            isDark = false,
        )
    }

    CompositionLocalProvider(LocalNardekColors provides extras) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = NardekTypography,
            content = content,
        )
    }
}

/** Atalho para as cores extras dentro das telas. */
object NardekTheme {
    val colors: NardekExtraColors
        @Composable get() = LocalNardekColors.current
}
