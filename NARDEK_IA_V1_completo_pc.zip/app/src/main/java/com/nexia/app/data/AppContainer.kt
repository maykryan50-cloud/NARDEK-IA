package com.nexia.app.data

import android.content.Context
import com.nexia.app.admin.AdminRepository
import com.nexia.app.auth.AuthRepository
import com.nexia.app.auth.AuthRepositoryImpl
import com.nexia.app.chat.ChatRepositoryHolder
import com.nexia.app.data.local.NardekPreferences
import com.nexia.app.data.remote.NardekBackend
import com.nexia.app.lab.LabRepository
import com.nexia.app.memory.MemoryRepository
import com.nexia.app.settings.SettingsRepository

/**
 * Container simples de dependências (sem framework de injeção).
 *
 * Criado uma vez em [com.nexia.app.MainActivity]. Guarda apenas objetos sem
 * estado de tela — o estado fica nos ViewModels.
 */
object AppContainer {

    private var initialized = false

    lateinit var preferences: NardekPreferences
        private set

    lateinit var backend: NardekBackend
        private set

    lateinit var authRepository: AuthRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var chatRepositories: ChatRepositoryHolder
        private set

    lateinit var adminRepository: AdminRepository
        private set

    lateinit var labRepository: LabRepository
        private set

    lateinit var memoryRepository: MemoryRepository
        private set

    fun init(context: Context) {
        if (initialized) return
        preferences = NardekPreferences(context)
        backend = NardekBackend()
        val tokenProvider = { preferences.authToken }
        authRepository = AuthRepositoryImpl(backend, preferences)
        settingsRepository = SettingsRepository(preferences)
        chatRepositories = ChatRepositoryHolder(backend, tokenProvider)
        adminRepository = AdminRepository(backend, tokenProvider)
        labRepository = LabRepository(backend, tokenProvider)
        memoryRepository = MemoryRepository(backend, tokenProvider)
        initialized = true
    }
}
