package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.lab.LabUiState
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette

/** NARDEK Lab: experimentos de desenvolvimento. Executar exige papel de equipe (servidor). */
@Composable
fun LabScreen(
    state: LabUiState,
    onBack: () -> Unit,
    onRun: (String, String) -> Unit,
    onResultShown: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.nav_lab),
            subtitle = stringResource(id = R.string.lab_subtitle),
            onBackClick = onBack,
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
        ) {
            items(items = state.experiments, key = { it.id }) { experiment ->
                Surface(
                    color = colors.surfaceHigh,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, colors.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = experiment.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = experiment.status,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (experiment.status == "disponivel") NardekPalette.Success else NardekPalette.Warning,
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = experiment.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary,
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { onRun(experiment.id, "teste da NARDEK IA") },
                            enabled = experiment.status == "disponivel",
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(id = R.string.lab_run)) }
                    }
                }
            }
        }
    }

    state.result?.let { result ->
        AlertDialog(
            onDismissRequest = onResultShown,
            title = { Text(stringResource(id = R.string.lab_result)) },
            text = { Text(result, style = MaterialTheme.typography.bodySmall) },
            confirmButton = {
                TextButton(onClick = onResultShown) { Text(stringResource(id = R.string.common_ok)) }
            },
            containerColor = colors.surfaceHigh,
        )
    }
}
