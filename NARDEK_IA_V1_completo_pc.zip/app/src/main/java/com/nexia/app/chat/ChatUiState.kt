package com.nexia.app.chat

import com.nexia.app.domain.model.AiModel
import com.nexia.app.domain.model.Conversation

/** Estado completo da tela de conversa. */
data class ChatUiState(
    val conversations: List<Conversation> = emptyList(),
    val activeConversationId: String? = null,
    val input: String = "",
    val isGenerating: Boolean = false,
    val engineLabel: String = "",
    val models: List<AiModel> = emptyList(),
    val selectedModelId: String = "nardek",
    val responseLanguageCode: String = "auto",
    val notice: String? = null,
) {
    val activeConversation: Conversation? get() = conversations.firstOrNull { it.id == activeConversationId }

    val messages get() = activeConversation?.messages.orEmpty()

    /** Conversas da mais recente para a mais antiga. */
    val ordered: List<Conversation> get() = conversations.sortedByDescending { it.updatedAt }

    val selectedModel: AiModel? get() = models.firstOrNull { it.id == selectedModelId }
}
