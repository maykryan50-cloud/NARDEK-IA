package com.nexia.app.settings

import androidx.lifecycle.ViewModel
import com.nexia.app.data.AppContainer
import com.nexia.app.domain.model.InterfaceLanguage
import com.nexia.app.domain.model.ResponseLanguage
import com.nexia.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.StateFlow

/** Ponte entre a tela de Configurações e as preferências guardadas. */
class SettingsViewModel : ViewModel() {

    private val repository = AppContainer.settingsRepository

    val state: StateFlow<AppSettings> = repository.state

    fun setThemeMode(mode: ThemeMode) = repository.setThemeMode(mode)

    fun setInterfaceLanguage(language: InterfaceLanguage) = repository.setInterfaceLanguage(language)

    fun setResponseLanguage(language: ResponseLanguage) = repository.setResponseLanguage(language)

    fun setStreamingEnabled(enabled: Boolean) = repository.setStreamingEnabled(enabled)

    fun backendUrl(): String = AppContainer.backend.baseUrl
}
