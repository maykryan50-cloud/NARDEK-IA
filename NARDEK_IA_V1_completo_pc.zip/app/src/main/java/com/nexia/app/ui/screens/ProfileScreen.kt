package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.chat.ChatUiState
import com.nexia.app.domain.model.Identity
import com.nexia.app.ui.components.NardekAvatar
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.components.NardekWordmark
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette

/** Perfil: identidade vinda do servidor, estatísticas da sessão e sessão de conta. */
@Composable
fun ProfileScreen(
    state: ChatUiState,
    identity: Identity?,
    onBack: () -> Unit,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    val totalMessages = state.conversations.sumOf { it.messages.size }
    val totalConversations = state.conversations.count { !it.isEmpty }

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.profile_title),
            subtitle = identity?.role?.id,
            onBackClick = onBack,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(8.dp))
            NardekAvatar(size = 92.dp)
            Spacer(Modifier.height(14.dp))
            Text(
                text = identity?.displayName ?: stringResource(id = R.string.account_guest),
                style = MaterialTheme.typography.headlineSmall,
                color = colors.textPrimary,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = identity?.email ?: stringResource(id = R.string.profile_not_signed),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
            )

            if (identity != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = NardekPalette.Cyan.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, NardekPalette.Cyan.copy(alpha = 0.5f)),
                ) {
                    Text(
                        text = identity.role.id,
                        style = MaterialTheme.typography.labelMedium,
                        color = NardekPalette.Cyan,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                StatCard(
                    label = stringResource(id = R.string.profile_stat_conversations),
                    value = totalConversations.toString(),
                    modifier = Modifier.weight(1f),
                )
                StatCard(
                    label = stringResource(id = R.string.profile_stat_messages),
                    value = totalMessages.toString(),
                    modifier = Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(16.dp))

            if (identity == null) {
                Button(
                    onClick = onSignIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                ) { Text(stringResource(id = R.string.profile_sign_in)) }
            } else {
                OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                ) { Text(stringResource(id = R.string.profile_sign_out)) }
            }

            Spacer(Modifier.height(16.dp))

            InfoBlock(
                icon = Icons.Filled.Person,
                title = stringResource(id = R.string.profile_roles_title),
                body = stringResource(id = R.string.profile_roles_body),
            )
            Spacer(Modifier.height(10.dp))
            InfoBlock(
                icon = Icons.Filled.Lock,
                title = stringResource(id = R.string.profile_privacy_title),
                body = stringResource(id = R.string.profile_privacy_body),
            )

            Spacer(Modifier.height(20.dp))
            NardekWordmark(fontSize = 14, letterSpacing = 3)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                color = NardekPalette.Cyan,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
            )
        }
    }
}

@Composable
private fun InfoBlock(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NardekPalette.Cyan,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
            )
        }
    }
}
