package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.BuildConfig
import com.nexia.app.R
import com.nexia.app.ui.components.NardekBrandBlock
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette

/** "Sobre a NARDEK": identidade, arquitetura e roteiro das próximas versões. */
@Composable
fun AboutScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    val roadmap = listOf(
        "V1" to stringResource(id = R.string.about_v1),
        "V2" to stringResource(id = R.string.about_v2),
        "V3" to stringResource(id = R.string.about_v3),
        "V4" to stringResource(id = R.string.about_v4),
        "V5" to stringResource(id = R.string.about_v5),
        "V6" to stringResource(id = R.string.about_v6),
        "V7" to stringResource(id = R.string.about_v7),
        "V8" to stringResource(id = R.string.about_v8),
        "V9" to stringResource(id = R.string.about_v9),
        "V10" to stringResource(id = R.string.about_v10),
    )

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.nav_about),
            subtitle = "v${BuildConfig.VERSION_NAME}",
            onBackClick = onBack,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            NardekBrandBlock(symbolSize = 84.dp, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))

            InfoCard(
                title = stringResource(id = R.string.about_what_title),
                body = stringResource(id = R.string.about_what_body),
            )
            Spacer(Modifier.height(10.dp))
            InfoCard(
                title = stringResource(id = R.string.about_arch_title),
                body = stringResource(id = R.string.about_arch_body),
            )
            Spacer(Modifier.height(10.dp))
            InfoCard(
                title = stringResource(id = R.string.about_firebase_title),
                body = stringResource(id = R.string.about_firebase_body, BuildConfig.FIREBASE_PROJECT_ID),
            )

            Spacer(Modifier.height(18.dp))
            Text(
                text = stringResource(id = R.string.about_roadmap).uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = colors.textMuted,
                modifier = Modifier.padding(start = 2.dp, bottom = 8.dp),
            )
            roadmap.forEach { (version, description) ->
                RoadmapRow(version, description, isCurrent = version == "V1")
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
            )
        }
    }
}

@Composable
private fun RoadmapRow(version: String, description: String, isCurrent: Boolean) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (isCurrent) NardekPalette.Cyan.copy(alpha = 0.10f) else colors.surfaceHigh,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (isCurrent) NardekPalette.Cyan.copy(alpha = 0.5f) else colors.outline,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = version,
                style = MaterialTheme.typography.labelLarge,
                color = NardekPalette.Cyan,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
            )
        }
    }
}
