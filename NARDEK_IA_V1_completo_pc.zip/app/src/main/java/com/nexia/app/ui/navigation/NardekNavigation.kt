package com.nexia.app.ui.navigation

/** Rotas de navegação da NARDEK IA. */
object NardekRoutes {
    const val CHAT = "chat"
    const val HISTORY = "history"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val LOGIN = "login"
    const val GOD_MODE = "god_mode"
    const val LAB = "lab"
}
