package com.nexia.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nexia.app.admin.AdminViewModel
import com.nexia.app.auth.AuthViewModel
import com.nexia.app.chat.ChatViewModel
import com.nexia.app.lab.LabViewModel
import com.nexia.app.settings.SettingsViewModel
import com.nexia.app.ui.components.NardekDrawerContent
import com.nexia.app.ui.components.NardekLocaleProvider
import com.nexia.app.ui.navigation.NardekRoutes
import com.nexia.app.ui.screens.AboutScreen
import com.nexia.app.ui.screens.ChatScreen
import com.nexia.app.ui.screens.GodModeScreen
import com.nexia.app.ui.screens.HistoryScreen
import com.nexia.app.ui.screens.LabScreen
import com.nexia.app.ui.screens.LoginScreen
import com.nexia.app.ui.screens.ProfileScreen
import com.nexia.app.ui.screens.SettingsScreen
import com.nexia.app.ui.theme.NardekTheme
import kotlinx.coroutines.launch

/**
 * Raiz da interface da NARDEK IA.
 *
 * Junta: tema (claro/escuro), idioma da interface, menu lateral e navegação.
 * O idioma das RESPOSTAS da IA é outro ajuste — ele viaja em cada mensagem.
 */
@Composable
fun NardekRoot() {
    val settingsViewModel: SettingsViewModel = viewModel()
    val authViewModel: AuthViewModel = viewModel()
    val chatViewModel: ChatViewModel = viewModel()
    val adminViewModel: AdminViewModel = viewModel()
    val labViewModel: LabViewModel = viewModel()

    val settings by settingsViewModel.state.collectAsStateWithLifecycle()
    val auth by authViewModel.state.collectAsStateWithLifecycle()
    val chat by chatViewModel.state.collectAsStateWithLifecycle()
    val admin by adminViewModel.state.collectAsStateWithLifecycle()
    val lab by labViewModel.state.collectAsStateWithLifecycle()

    NardekTheme(themeMode = settings.themeMode) {
        NardekLocaleProvider(language = settings.interfaceLanguage) {
            NardekContent(
                settingsViewModel = settingsViewModel,
                authViewModel = authViewModel,
                chatViewModel = chatViewModel,
                adminViewModel = adminViewModel,
                labViewModel = labViewModel,
                settings = settings,
                auth = auth,
                chat = chat,
                admin = admin,
                lab = lab,
            )
        }
    }
}

@Composable
private fun NardekContent(
    settingsViewModel: SettingsViewModel,
    authViewModel: AuthViewModel,
    chatViewModel: ChatViewModel,
    adminViewModel: AdminViewModel,
    labViewModel: LabViewModel,
    settings: com.nexia.app.settings.AppSettings,
    auth: com.nexia.app.auth.AuthUiState,
    chat: com.nexia.app.chat.ChatUiState,
    admin: com.nexia.app.admin.AdminUiState,
    lab: com.nexia.app.lab.LabUiState,
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun closeDrawer() = scope.launch { drawerState.close() }

    fun navigate(route: String) {
        closeDrawer()
        if (navController.currentDestination?.route != route) {
            navController.navigate(route) { launchSingleTop = true }
        }
    }

    fun toast(message: String) = scope.launch { snackbarHostState.showSnackbar(message) }

    Surface {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                    drawerContentColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                ) {
                    NardekDrawerContent(
                        conversations = chat.ordered,
                        activeConversationId = chat.activeConversationId,
                        identity = auth.identity,
                        engineLabel = chat.engineLabel,
                        onNewChat = {
                            chatViewModel.newConversation()
                            navigate(NardekRoutes.CHAT)
                        },
                        onSelectConversation = { id ->
                            chatViewModel.selectConversation(id)
                            navigate(NardekRoutes.CHAT)
                        },
                        onOpenHistory = { navigate(NardekRoutes.HISTORY) },
                        onOpenProfile = { navigate(NardekRoutes.PROFILE) },
                        onOpenSettings = { navigate(NardekRoutes.SETTINGS) },
                        onOpenAbout = { navigate(NardekRoutes.ABOUT) },
                        onOpenGodMode = {
                            adminViewModel.load()
                            navigate(NardekRoutes.GOD_MODE)
                        },
                        onOpenLab = { navigate(NardekRoutes.LAB) },
                    )
                }
            },
        ) {
            Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = NardekRoutes.CHAT,
                    modifier = Modifier.padding(innerPadding),
                ) {
                    composable(NardekRoutes.CHAT) {
                        ChatScreen(
                            state = chat,
                            onOpenDrawer = { scope.launch { drawerState.open() } },
                            onInputChange = chatViewModel::onInputChange,
                            onSend = {
                                chatViewModel.syncLanguageFromSettings()
                                chatViewModel.send()
                            },
                            onStop = chatViewModel::stopGenerating,
                            onSuggestionClick = chatViewModel::onSuggestionClick,
                            onAttachClick = { toast("Anexos chegam na V5 — o botão já está no lugar.") },
                            onModelSelected = chatViewModel::onModelSelected,
                            onNoticeShown = chatViewModel::consumeNotice,
                        )
                    }

                    composable(NardekRoutes.HISTORY) {
                        HistoryScreen(
                            state = chat,
                            onBack = { navController.popBackStack() },
                            onSelectConversation = { id ->
                                chatViewModel.selectConversation(id)
                                navController.navigate(NardekRoutes.CHAT) { launchSingleTop = true }
                            },
                            onRenameConversation = chatViewModel::renameConversation,
                            onDeleteConversation = chatViewModel::deleteConversation,
                        )
                    }

                    composable(NardekRoutes.PROFILE) {
                        ProfileScreen(
                            state = chat,
                            identity = auth.identity,
                            onBack = { navController.popBackStack() },
                            onSignIn = { navigate(NardekRoutes.LOGIN) },
                            onSignOut = {
                                authViewModel.signOut()
                                chatViewModel.loadModels()
                                toast("Sessão encerrada.")
                            },
                        )
                    }

                    composable(NardekRoutes.SETTINGS) {
                        SettingsScreen(
                            settings = settings,
                            backendUrl = settingsViewModel.backendUrl(),
                            signedInLabel = auth.identity?.email ?: "sem conta",
                            onBack = { navController.popBackStack() },
                            onThemeChange = settingsViewModel::setThemeMode,
                            onInterfaceLanguageChange = settingsViewModel::setInterfaceLanguage,
                            onResponseLanguageChange = { language ->
                                settingsViewModel.setResponseLanguage(language)
                                chatViewModel.syncLanguageFromSettings()
                            },
                            onStreamingChange = settingsViewModel::setStreamingEnabled,
                            onClearConversations = {
                                chatViewModel.clearAllConversations()
                                toast("Conversas apagadas.")
                            },
                        )
                    }

                    composable(NardekRoutes.ABOUT) {
                        AboutScreen(onBack = { navController.popBackStack() })
                    }

                    composable(NardekRoutes.LOGIN) {
                        LoginScreen(
                            isLoading = auth.isLoading,
                            error = auth.error,
                            onSignIn = { email, name -> authViewModel.signIn(email, name) },
                            onContinueOffline = { navController.popBackStack() },
                            onGoogleClick = {
                                toast(
                                    "O login com Google entra na V3: faltam as bibliotecas do " +
                                        "Firebase e o SHA-1 do certificado de assinatura.",
                                )
                            },
                        )
                    }

                    composable(NardekRoutes.GOD_MODE) {
                        GodModeScreen(
                            state = admin,
                            isOwner = auth.identity?.role?.id == "OWNER",
                            onBack = { navController.popBackStack() },
                            onRefresh = adminViewModel::load,
                            onKillSwitch = adminViewModel::setKillSwitch,
                            onChangeRole = { uid, role -> adminViewModel.changeRole(uid, role) },
                            onToggleBlocked = { uid, blocked -> adminViewModel.setBlocked(uid, blocked) },
                            onSetDailyLimit = { uid, limit -> adminViewModel.setDailyLimit(uid, limit) },
                            onRunTool = adminViewModel::runTool,
                            onMessageShown = adminViewModel::consumeMessage,
                        )
                    }

                    composable(NardekRoutes.LAB) {
                        LabScreen(
                            state = lab,
                            onBack = { navController.popBackStack() },
                            onRun = labViewModel::run,
                            onResultShown = labViewModel::consumeResult,
                        )
                    }
                }
            }
        }
    }
}
