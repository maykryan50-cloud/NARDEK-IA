package com.nexia.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.domain.model.ChatMessage
import com.nexia.app.ui.theme.NardekPalette
import com.nexia.app.ui.theme.LocalNardekColors

/** Bolha da mensagem do usuário. */
@Composable
fun UserMessageBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
    ) {
        Surface(
            color = colors.userBubble,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp),
            border = BorderStroke(1.dp, NardekPalette.Blue.copy(alpha = 0.35f)),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textPrimary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(id = R.string.chat_you),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textMuted,
        )
    }
}

/** Bolha da resposta da IA, com o avatar da marca. */
@Composable
fun AssistantMessageBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        NardekAvatar(size = 30.dp)
        Spacer(Modifier.size(10.dp))
        Column(modifier = Modifier.widthIn(max = 330.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(id = R.string.app_name),
                    style = MaterialTheme.typography.labelMedium,
                    color = NardekPalette.Cyan,
                    fontWeight = FontWeight.SemiBold,
                )
                if (message.language != null) {
                    Spacer(Modifier.size(6.dp))
                    Text(
                        text = "· ${message.language}",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textMuted,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Surface(
                color = if (message.isError) NardekPalette.ErrorContainer else colors.assistantBubble,
                shape = RoundedCornerShape(topStart = 6.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (message.isError) NardekPalette.Error.copy(alpha = 0.5f) else colors.outline,
                ),
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (message.isError) NardekPalette.Error else colors.textPrimary,
                    )
                    if (message.isStreaming) {
                        Spacer(Modifier.height(6.dp))
                        StreamingCaret()
                    }
                }
            }
        }
    }
}

/** Cursor pulsante enquanto a NARDEK escreve. */
@Composable
private fun StreamingCaret() {
    val transition = rememberInfiniteTransition(label = "caret")
    val alpha by transition.animateFloat(
        initialValue = 0.15f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse),
        label = "caretAlpha",
    )
    Box(
        modifier = Modifier
            .size(width = 9.dp, height = 15.dp)
            .alpha(alpha)
            .background(NardekPalette.Cyan, RoundedCornerShape(2.dp)),
    )
}

/** Indicador "NARDEK IA está digitando" (mostrado enquanto a resposta não chegou). */
@Composable
fun TypingIndicator(modifier: Modifier = Modifier) {
    val colors = LocalNardekColors.current
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        NardekAvatar(size = 30.dp)
        Spacer(Modifier.size(10.dp))
        Surface(
            color = colors.assistantBubble,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, colors.outline),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(id = R.string.chat_typing),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                )
                Spacer(Modifier.size(8.dp))
                repeat(3) { index ->
                    AnimatedDot(delayMillis = index * 160)
                    if (index < 2) Spacer(Modifier.size(4.dp))
                }
            }
        }
    }
}

@Composable
private fun AnimatedDot(delayMillis: Int) {
    val transition = rememberInfiniteTransition(label = "dot")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(700 + delayMillis, easing = LinearEasing),
            RepeatMode.Reverse,
        ),
        label = "dotOffset",
    )
    Box(
        modifier = Modifier
            .size(5.dp)
            .alpha(0.35f + offset * 0.65f)
            .background(NardekPalette.Cyan, CircleShape),
    )
}
