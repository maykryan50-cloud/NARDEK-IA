package com.nexia.app.lab

import com.nexia.app.data.remote.NardekBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * NARDEK Lab — experimentos.
 * O aplicativo só lista e dispara experimentos; a autorização é do servidor.
 */
class LabRepository(
    private val backend: NardekBackend,
    private val tokenProvider: () -> String?,
) {

    data class Experiment(
        val id: String,
        val title: String,
        val description: String,
        val status: String,
    )

    suspend fun experiments(): List<Experiment> = withContext(Dispatchers.IO) {
        val response = backend.get("/api/v1/lab/experiments", tokenProvider())
        if (!response.isOk) return@withContext emptyList()
        runCatching {
            val array = JSONObject(response.body).getJSONArray("experiments")
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                Experiment(
                    id = item.optString("id"),
                    title = item.optString("title"),
                    description = item.optString("description"),
                    status = item.optString("status"),
                )
            }
        }.getOrDefault(emptyList())
    }

    suspend fun run(experimentId: String, input: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("input", input).toString()
        val response = backend.post("/api/v1/lab/experiments/$experimentId/run", body, tokenProvider())
        if (response.isOk) {
            runCatching { JSONObject(response.body).toString(2) }.getOrDefault(response.body)
        } else {
            runCatching { JSONObject(response.body).optString("detail") }
                .getOrDefault("Erro HTTP ${response.statusCode}")
        }
    }
}
