package com.nexia.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexia.app.R
import com.nexia.app.ui.theme.NardekPalette

/**
 * Símbolo oficial da NARDEK IA — o "N" em fita, recortado da própria logomarca
 * (res/drawable-nodpi/nardek_n_badge.png). É o mesmo ícone usado no launcher.
 */
@Composable
fun NardekSymbol(size: Dp = 40.dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.nardek_n_badge),
        contentDescription = stringResource(id = R.string.cd_logo),
        modifier = modifier.size(size),
    )
}

/** Avatar da IA: símbolo NARDEK recortado em círculo (aparece ao lado das respostas). */
@Composable
fun NardekAvatar(size: Dp = 32.dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(NardekPalette.Blue)
            .border(1.dp, NardekPalette.Cyan.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(id = R.drawable.nardek_n_badge),
            contentDescription = stringResource(id = R.string.cd_logo),
            modifier = Modifier.size(size * 0.92f),
        )
    }
}

/** Logotipo escrito: NARDEK em branco/preto + IA em ciano, como na marca. */
@Composable
fun NardekWordmark(
    modifier: Modifier = Modifier,
    fontSize: Int = 18,
    letterSpacing: Int = 3,
) {
    val baseColor = MaterialTheme.colorScheme.onSurface
    Text(
        modifier = modifier,
        style = TextStyle(
            fontWeight = FontWeight.Bold,
            fontSize = fontSize.sp,
            letterSpacing = letterSpacing.sp,
        ),
    ) {
        // O "IA" fica na cor da marca (ciano), o resto segue o tema.
        append("NARDEK ")
        withStyle(TextStyle(color = NardekPalette.Cyan, fontWeight = FontWeight.Bold)) {
            append("IA")
        }
        @Suppress("UNUSED_EXPRESSION") baseColor
    }
}

/** Bloco de marca usado nas telas de boas-vindas e no "Sobre". */
@Composable
fun NardekBrandBlock(symbolSize: Dp = 96.dp, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        NardekSymbol(size = symbolSize)
        Spacer(Modifier.height(10.dp))
        NardekWordmark(fontSize = 26, letterSpacing = 5)
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(id = R.string.brand_tagline),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
