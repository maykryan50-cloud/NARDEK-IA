package com.nexia.app.settings

import com.nexia.app.data.local.NardekPreferences
import com.nexia.app.domain.model.InterfaceLanguage
import com.nexia.app.domain.model.ResponseLanguage
import com.nexia.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Estado das preferências visível para as telas. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val interfaceLanguage: InterfaceLanguage = InterfaceLanguage.SYSTEM,
    val responseLanguage: ResponseLanguage = ResponseLanguage.AUTO,
    val aiFollowsMessageLanguage: Boolean = true,
    val selectedModelId: String = "nardek",
    val streamingEnabled: Boolean = true,
)

/**
 * Repositório de preferências (tema, idiomas, modelo).
 * Mantém um [StateFlow] para que toda a interface reaja na hora.
 */
class SettingsRepository(private val preferences: NardekPreferences) {

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun read() = AppSettings(
        themeMode = preferences.themeMode,
        interfaceLanguage = preferences.interfaceLanguage,
        responseLanguage = preferences.responseLanguage,
        aiFollowsMessageLanguage = preferences.aiFollowsMessageLanguage,
        selectedModelId = preferences.selectedModelId,
        streamingEnabled = preferences.streamingEnabled,
    )

    fun setThemeMode(mode: ThemeMode) {
        preferences.themeMode = mode
        _state.value = _state.value.copy(themeMode = mode)
    }

    /** Idioma da interface — muda os textos do aplicativo imediatamente. */
    fun setInterfaceLanguage(language: InterfaceLanguage) {
        preferences.interfaceLanguage = language
        _state.value = _state.value.copy(interfaceLanguage = language)
    }

    /** Idioma das respostas da IA. */
    fun setResponseLanguage(language: ResponseLanguage) {
        preferences.responseLanguage = language
        preferences.aiFollowsMessageLanguage = language == ResponseLanguage.AUTO
        _state.value = _state.value.copy(
            responseLanguage = language,
            aiFollowsMessageLanguage = language == ResponseLanguage.AUTO,
        )
    }

    fun setSelectedModel(modelId: String) {
        preferences.selectedModelId = modelId
        _state.value = _state.value.copy(selectedModelId = modelId)
    }

    fun setStreamingEnabled(enabled: Boolean) {
        preferences.streamingEnabled = enabled
        _state.value = _state.value.copy(streamingEnabled = enabled)
    }
}
