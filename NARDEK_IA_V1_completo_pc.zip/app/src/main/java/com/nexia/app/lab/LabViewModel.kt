package com.nexia.app.lab

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexia.app.data.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Estado da área de experimentos (NARDEK Lab). */
data class LabUiState(
    val experiments: List<LabRepository.Experiment> = emptyList(),
    val isLoading: Boolean = false,
    val result: String? = null,
    val error: String? = null,
)

/**
 * NARDEK Lab. A execução de experimentos é restrita à equipe pelo servidor:
 * se um usuário comum tentar, o backend responde 403 e a mensagem aparece aqui.
 */
class LabViewModel : ViewModel() {

    private val repository = AppContainer.labRepository

    private val _state = MutableStateFlow(LabUiState())
    val state: StateFlow<LabUiState> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        _state.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            val experiments = repository.experiments()
            _state.update { it.copy(experiments = experiments, isLoading = false) }
        }
    }

    fun run(experimentId: String, input: String) {
        viewModelScope.launch {
            val output = repository.run(experimentId, input)
            _state.update { it.copy(result = output, error = null) }
        }
    }

    fun consumeResult() = _state.update { it.copy(result = null, error = null) }
}
