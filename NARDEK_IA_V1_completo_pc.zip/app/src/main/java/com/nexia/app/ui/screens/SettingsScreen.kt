package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.domain.model.InterfaceLanguage
import com.nexia.app.domain.model.ResponseLanguage
import com.nexia.app.domain.model.ThemeMode
import com.nexia.app.settings.AppSettings
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette

/**
 * Configurações: tema (claro/escuro/sistema), sistema de idiomas
 * (interface × respostas da IA) e preferências de conversa.
 */
@Composable
fun SettingsScreen(
    settings: AppSettings,
    backendUrl: String,
    signedInLabel: String?,
    onBack: () -> Unit,
    onThemeChange: (ThemeMode) -> Unit,
    onInterfaceLanguageChange: (InterfaceLanguage) -> Unit,
    onResponseLanguageChange: (ResponseLanguage) -> Unit,
    onStreamingChange: (Boolean) -> Unit,
    onClearConversations: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    var confirmClear by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.settings_title),
            subtitle = signedInLabel,
            onBackClick = onBack,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            // ---------------- Aparência ----------------
            SectionTitle(stringResource(id = R.string.settings_appearance))
            Text(
                text = stringResource(id = R.string.settings_theme),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeChip(
                    label = stringResource(id = R.string.settings_theme_system),
                    selected = settings.themeMode == ThemeMode.SYSTEM,
                    onClick = { onThemeChange(ThemeMode.SYSTEM) },
                    modifier = Modifier.weight(1f),
                )
                ThemeChip(
                    label = stringResource(id = R.string.settings_theme_light),
                    selected = settings.themeMode == ThemeMode.LIGHT,
                    onClick = { onThemeChange(ThemeMode.LIGHT) },
                    modifier = Modifier.weight(1f),
                )
                ThemeChip(
                    label = stringResource(id = R.string.settings_theme_dark),
                    selected = settings.themeMode == ThemeMode.DARK,
                    onClick = { onThemeChange(ThemeMode.DARK) },
                    modifier = Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(20.dp))

            // ---------------- Idiomas ----------------
            SectionTitle(stringResource(id = R.string.settings_languages))

            Text(
                text = stringResource(id = R.string.settings_interface_language),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
            )
            Text(
                text = stringResource(id = R.string.settings_interface_language_hint),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            InterfaceLanguage.entries.forEach { language ->
                OptionRow(
                    label = "${language.flag}  ${language.nativeLabel}",
                    selected = settings.interfaceLanguage == language,
                    onClick = { onInterfaceLanguageChange(language) },
                )
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = stringResource(id = R.string.settings_ai_language),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
            )
            Text(
                text = stringResource(id = R.string.settings_ai_language_hint),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            ResponseLanguage.entries.forEach { language ->
                OptionRow(
                    label = if (language == ResponseLanguage.AUTO) {
                        "🌐  ${stringResource(id = R.string.settings_ai_follows)}"
                    } else {
                        "${language.flag}  ${language.nativeLabel}"
                    },
                    selected = settings.responseLanguage == language,
                    onClick = { onResponseLanguageChange(language) },
                )
            }

            Spacer(Modifier.height(20.dp))

            // ---------------- Conversa ----------------
            SectionTitle(stringResource(id = R.string.settings_conversation))
            Surface(
                color = colors.surfaceHigh,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.outline),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(id = R.string.settings_streaming),
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary,
                        )
                        Text(
                            text = stringResource(id = R.string.settings_streaming_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textMuted,
                        )
                    }
                    Switch(
                        checked = settings.streamingEnabled,
                        onCheckedChange = onStreamingChange,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF04121C),
                            checkedTrackColor = NardekPalette.Cyan,
                            uncheckedTrackColor = colors.outline,
                        ),
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---------------- Servidor ----------------
            SectionTitle(stringResource(id = R.string.settings_server))
            InfoBlock(
                title = stringResource(id = R.string.settings_backend_url),
                value = backendUrl,
                body = stringResource(id = R.string.settings_backend_hint),
            )

            Spacer(Modifier.height(20.dp))

            SectionTitle(stringResource(id = R.string.settings_data))
            OutlinedButton(
                onClick = { confirmClear = true },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(id = R.string.settings_clear_conversations),
                    color = NardekPalette.Error,
                    fontWeight = FontWeight.SemiBold,
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(stringResource(id = R.string.settings_clear_title)) },
            text = { Text(stringResource(id = R.string.settings_clear_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    onClearConversations()
                }) { Text(stringResource(id = R.string.common_delete), color = NardekPalette.Error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) {
                    Text(stringResource(id = R.string.common_cancel), color = colors.textSecondary)
                }
            },
            containerColor = colors.surfaceHigh,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = LocalNardekColors.current.textMuted,
        modifier = Modifier.padding(bottom = 8.dp, start = 2.dp),
    )
}

@Composable
private fun ThemeChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (selected) NardekPalette.Cyan.copy(alpha = 0.18f) else colors.surfaceHigh,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (selected) NardekPalette.Cyan else colors.outline,
        ),
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (selected) NardekPalette.Cyan else colors.textSecondary,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.padding(vertical = 12.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun OptionRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (selected) NardekPalette.Cyan.copy(alpha = 0.10f) else colors.surfaceHigh,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (selected) NardekPalette.Cyan.copy(alpha = 0.6f) else colors.outline),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) NardekPalette.Cyan else colors.textPrimary,
                modifier = Modifier.weight(1f),
            )
            if (selected) {
                Text(
                    text = "✓",
                    style = MaterialTheme.typography.bodyLarge,
                    color = NardekPalette.Cyan,
                )
            }
        }
    }
}

@Composable
private fun InfoBlock(title: String, value: String, body: String) {
    val colors = LocalNardekColors.current
    Surface(
        color = colors.surfaceHigh,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = NardekPalette.Cyan,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
            )
        }
    }
}
