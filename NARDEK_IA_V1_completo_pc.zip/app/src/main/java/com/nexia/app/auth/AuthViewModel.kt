package com.nexia.app.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexia.app.data.AppContainer
import com.nexia.app.domain.model.Identity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Estado da sessão do usuário. */
data class AuthUiState(
    val identity: Identity? = null,
    val isLoading: Boolean = false,
    val error: String? = null,
) {
    val isSignedIn: Boolean get() = identity != null
    val canSeeGodMode: Boolean get() = identity?.role?.canSeeGodMode == true
}

/**
 * Sessão do usuário.
 *
 * O aplicativo não decide papéis: ele pergunta ao servidor (/api/v1/me) e
 * apenas reflete a resposta na interface.
 */
class AuthViewModel : ViewModel() {

    private val repository = AppContainer.authRepository

    private val _state = MutableStateFlow(AuthUiState(identity = repository.signedIdentity()))
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    /** Revalida a sessão atual no servidor (pega mudanças de papel na hora). */
    fun refresh() {
        viewModelScope.launch {
            val result = repository.refreshIdentity() ?: return@launch
            when (result) {
                is AuthResult.Success -> _state.update { it.copy(identity = result.identity, error = null) }
                is AuthResult.Failure -> _state.update { it.copy(identity = null, error = result.message) }
            }
        }
    }

    fun signIn(email: String, displayName: String) {
        if (email.isBlank()) {
            _state.update { it.copy(error = "Informe um e-mail para continuar.") }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            when (val result = repository.signIn(email, displayName)) {
                is AuthResult.Success ->
                    _state.update { it.copy(identity = result.identity, isLoading = false, error = null) }
                is AuthResult.Failure ->
                    _state.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }

    fun signOut() {
        repository.signOut()
        _state.value = AuthUiState()
    }

    fun consumeError() = _state.update { it.copy(error = null) }
}
