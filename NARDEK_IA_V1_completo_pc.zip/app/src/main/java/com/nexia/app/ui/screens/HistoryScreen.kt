package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.chat.ChatUiState
import com.nexia.app.domain.model.Conversation
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico: lista as conversas da sessão, com renomear e excluir. */
@Composable
fun HistoryScreen(
    state: ChatUiState,
    onBack: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    val conversations = state.ordered
    var renaming by remember { mutableStateOf<Conversation?>(null) }
    var deleting by remember { mutableStateOf<Conversation?>(null) }
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy · HH:mm", Locale.getDefault()) }

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.history_title),
            subtitle = stringResource(id = R.string.history_count, conversations.size),
            onBackClick = onBack,
        )

        if (conversations.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = stringResource(id = R.string.history_empty_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(id = R.string.history_empty_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textMuted,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
            ) {
                items(items = conversations, key = { it.id }) { conversation ->
                    ConversationCard(
                        conversation = conversation,
                        subtitle = dateFormat.format(Date(conversation.updatedAt)),
                        isActive = conversation.id == state.activeConversationId,
                        onClick = { onSelectConversation(conversation.id) },
                        onRename = { renaming = conversation },
                        onDelete = { deleting = conversation },
                        modifier = Modifier.padding(bottom = 10.dp),
                    )
                }
            }
        }
    }

    // --- Diálogo de renomear ---
    renaming?.let { conversation ->
        var text by remember(conversation.id) { mutableStateOf(conversation.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(stringResource(id = R.string.history_rename_title)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text(stringResource(id = R.string.history_rename_label)) },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRenameConversation(conversation.id, text)
                    renaming = null
                }) { Text(stringResource(id = R.string.common_save)) }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) {
                    Text(stringResource(id = R.string.common_cancel), color = colors.textSecondary)
                }
            },
            containerColor = colors.surfaceHigh,
        )
    }

    // --- Diálogo de excluir ---
    deleting?.let { conversation ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(id = R.string.history_delete_title)) },
            text = { Text(stringResource(id = R.string.history_delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteConversation(conversation.id)
                    deleting = null
                }) { Text(stringResource(id = R.string.common_delete), color = NardekPalette.Error) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) {
                    Text(stringResource(id = R.string.common_cancel), color = colors.textSecondary)
                }
            },
            containerColor = colors.surfaceHigh,
        )
    }
}

@Composable
private fun ConversationCard(
    conversation: Conversation,
    subtitle: String,
    isActive: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (isActive) colors.surfaceHigh else colors.surfaceHigh.copy(alpha = 0.55f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp,
            if (isActive) NardekPalette.Cyan.copy(alpha = 0.5f) else colors.outline,
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = conversation.title.ifBlank { stringResource(id = R.string.history_untitled) },
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = conversation.preview.take(90).replace("\n", " ")
                        .ifBlank { stringResource(id = R.string.history_no_messages) },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 2,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "$subtitle · ${stringResource(id = R.string.history_messages, conversation.messages.size)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textMuted,
                )
            }

            IconButton(onClick = onRename) {
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = stringResource(id = R.string.history_rename_title),
                    tint = colors.textMuted,
                    modifier = Modifier.size(20.dp),
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = stringResource(id = R.string.common_delete),
                    tint = colors.textMuted,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
    }
}
