package com.nexia.app.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexia.app.data.AppContainer
import com.nexia.app.data.repository.ChatOutcome
import com.nexia.app.domain.model.AiModel
import com.nexia.app.domain.model.ChatMessage
import com.nexia.app.domain.model.ChatRole
import com.nexia.app.domain.model.Conversation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Estado e regras da tela de conversa.
 *
 * A resposta vem do [com.nexia.app.data.repository.ChatRepository] escolhido pelo
 * [ChatRepositoryHolder]: backend (com sessão) ou motor local (sem sessão).
 */
class ChatViewModel : ViewModel() {

    private val repositories = AppContainer.chatRepositories
    private val settings = AppContainer.settingsRepository

    private val _state = MutableStateFlow(
        ChatUiState(
            engineLabel = if (repositories.isOnlineAvailable) "Servidor NARDEK" else "Modo local",
            selectedModelId = settings.state.value.selectedModelId,
            responseLanguageCode = settings.state.value.responseLanguage.code,
        ),
    )
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private var generationJob: Job? = null

    init {
        newConversation()
        loadModels()
    }

    /** Modelos disponíveis: vêm do servidor, filtrados pelo papel do usuário. */
    fun loadModels() {
        viewModelScope.launch {
            val models = if (repositories.isOnlineAvailable) {
                fetchModels()
            } else {
                listOf(
                    AiModel(
                        id = "nardek",
                        name = "NARDEK (modo local)",
                        description = "Respondendo no aparelho, sem internet. Entre na conta para usar o servidor.",
                        isDefault = true,
                    ),
                )
            }
            _state.update { current ->
                current.copy(
                    models = models,
                    selectedModelId = models.firstOrNull { it.id == current.selectedModelId }?.id
                        ?: models.firstOrNull()?.id ?: "nardek",
                    engineLabel = if (repositories.isOnlineAvailable) "Servidor NARDEK" else "Modo local",
                )
            }
        }
    }

    private suspend fun fetchModels(): List<AiModel> {
        val response = AppContainer.backend.get("/api/v1/chat/models", AppContainer.preferences.authToken)
        if (!response.isOk) return emptyList()
        return runCatching {
            val array = org.json.JSONObject(response.body).getJSONArray("models")
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                AiModel(
                    id = item.optString("id"),
                    name = item.optString("name"),
                    description = item.optString("description"),
                    isDefault = index == 0,
                )
            }
        }.getOrDefault(emptyList())
    }

    // ------------------------------------------------------------------ estado

    fun onInputChange(value: String) = _state.update { it.copy(input = value) }

    fun onModelSelected(modelId: String) {
        settings.setSelectedModel(modelId)
        _state.update { it.copy(selectedModelId = modelId) }
    }

    /**
     * Aplica o idioma das respostas escolhido nas Configurações.
     * "auto" = o servidor responde no idioma da mensagem.
     */
    fun syncLanguageFromSettings() {
        _state.update { it.copy(responseLanguageCode = settings.state.value.responseLanguage.code) }
    }

    fun consumeNotice() = _state.update { it.copy(notice = null) }

    // ------------------------------------------------------------------ ações

    fun newConversation() {
        stopGenerating()
        val conversation = Conversation()
        _state.update {
            it.copy(
                conversations = listOf(conversation) + it.conversations,
                activeConversationId = conversation.id,
                input = "",
                isGenerating = false,
            )
        }
    }

    fun selectConversation(id: String) {
        stopGenerating()
        _state.update { it.copy(activeConversationId = id) }
    }

    /** Renomeia uma conversa (usado no Histórico). */
    fun renameConversation(id: String, title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        updateConversation(id) { it.copy(title = clean, updatedAt = System.currentTimeMillis()) }
    }

    fun deleteConversation(id: String) {
        val remaining = _state.value.conversations.filterNot { it.id == id }
        if (remaining.isEmpty()) {
            newConversation()
            return
        }
        _state.update {
            it.copy(
                conversations = remaining,
                activeConversationId = if (it.activeConversationId == id) remaining.first().id else it.activeConversationId,
            )
        }
    }

    fun clearAllConversations() {
        _state.value = _state.value.copy(conversations = emptyList())
        newConversation()
    }

    fun onSuggestionClick(text: String) {
        onInputChange(text)
        send()
    }

    fun send() {
        val prompt = _state.value.input.trim()
        val conversationId = _state.value.activeConversationId
        if (prompt.isEmpty() || conversationId == null || _state.value.isGenerating) return

        val userMessage = ChatMessage(role = ChatRole.USER, text = prompt)
        updateConversation(conversationId) { conversation ->
            conversation.copy(
                title = if (conversation.isEmpty) deriveTitle(prompt) else conversation.title,
                messages = conversation.messages + userMessage,
                updatedAt = System.currentTimeMillis(),
            )
        }
        _state.update { it.copy(input = "", isGenerating = true) }

        val history = _state.value.messages.dropLast(1)
        val assistantId = "assistant-${System.currentTimeMillis()}"
        val modelId = _state.value.selectedModelId
        val languageCode = _state.value.responseLanguageCode

        generationJob = viewModelScope.launch {
            when (val outcome = repositories.current().send(prompt, history, modelId, languageCode, conversationId)) {
                is ChatOutcome.Success -> {
                    // A V1 revela a resposta em blocos (efeito de escrita).
                    // O streaming real do servidor (SSE) entra na V2.
                    appendAssistant(conversationId, assistantId, "", isStreaming = true, isError = false, language = outcome.language)
                    val chunks = outcome.reply.chunked(18)
                    val builder = StringBuilder()
                    for (chunk in chunks) {
                        builder.append(chunk)
                        upsertAssistant(conversationId, assistantId, builder.toString(), isStreaming = true, isError = false, language = outcome.language)
                        delay(22)
                    }
                    upsertAssistant(conversationId, assistantId, outcome.reply, isStreaming = false, isError = false, language = outcome.language)
                }

                is ChatOutcome.Failure -> {
                    val text = buildString {
                        append(outcome.message)
                        if (outcome.hint != null) append("\n\n").append(outcome.hint)
                    }
                    appendAssistant(conversationId, assistantId, text, isStreaming = false, isError = true, language = null)
                    _state.update { it.copy(notice = outcome.hint) }
                }
            }
            _state.update { it.copy(isGenerating = false) }
        }
    }

    fun stopGenerating() {
        generationJob?.cancel()
        generationJob = null
        _state.update { current ->
            current.copy(
                isGenerating = false,
                conversations = current.conversations.map { conversation ->
                    conversation.copy(
                        messages = conversation.messages.map { message ->
                            if (message.isStreaming) message.copy(isStreaming = false) else message
                        },
                    )
                },
            )
        }
    }

    // ------------------------------------------------------------------ utils

    private fun appendAssistant(
        conversationId: String,
        assistantId: String,
        text: String,
        isStreaming: Boolean,
        isError: Boolean,
        language: String?,
    ) {
        updateConversation(conversationId) { conversation ->
            conversation.copy(
                messages = conversation.messages + ChatMessage(
                    id = assistantId,
                    role = ChatRole.ASSISTANT,
                    text = text,
                    isStreaming = isStreaming,
                    isError = isError,
                    language = language,
                ),
                updatedAt = System.currentTimeMillis(),
            )
        }
    }

    private fun upsertAssistant(
        conversationId: String,
        assistantId: String,
        text: String,
        isStreaming: Boolean,
        isError: Boolean,
        language: String?,
    ) {
        updateConversation(conversationId) { conversation ->
            conversation.copy(
                messages = conversation.messages.map { message ->
                    if (message.id == assistantId) {
                        message.copy(text = text, isStreaming = isStreaming, isError = isError, language = language)
                    } else {
                        message
                    }
                },
            )
        }
    }

    private fun updateConversation(id: String, transform: (Conversation) -> Conversation) {
        _state.update { current ->
            current.copy(
                conversations = current.conversations.map { conversation ->
                    if (conversation.id == id) transform(conversation) else conversation
                },
            )
        }
    }

    private fun deriveTitle(firstMessage: String): String {
        val clean = firstMessage.replace("\n", " ").trim()
        return if (clean.length <= 34) clean else clean.take(33).trimEnd() + "…"
    }
}
