package com.nexia.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.domain.model.Conversation
import com.nexia.app.domain.model.Identity
import com.nexia.app.ui.theme.NardekPalette
import com.nexia.app.ui.theme.LocalNardekColors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Menu lateral: identidade, nova conversa, conversas agrupadas por data,
 * navegação, Modo Deus (só aparece para quem o SERVIDOR autoriza) e rodapé da conta.
 */
@Composable
fun NardekDrawerContent(
    conversations: List<Conversation>,
    activeConversationId: String?,
    identity: Identity?,
    engineLabel: String,
    onNewChat: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenGodMode: () -> Unit,
    onOpenLab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NardekAvatar(size = 42.dp)
            Spacer(Modifier.size(12.dp))
            Column {
                NardekWordmark(fontSize = 17, letterSpacing = 2)
                Text(
                    text = engineLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textMuted,
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        DrawerAction(
            icon = Icons.Filled.Add,
            label = stringResource(id = R.string.nav_new_chat),
            highlighted = true,
            onClick = onNewChat,
        )

        Spacer(Modifier.height(16.dp))
        SectionLabel(stringResource(id = R.string.drawer_recent).uppercase())

        val groups = groupByDay(conversations)
        if (groups.isEmpty()) {
            Text(
                text = stringResource(id = R.string.drawer_no_conversations),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textMuted,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            )
        } else {
            groups.forEach { (label, items) ->
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textMuted,
                    modifier = Modifier.padding(start = 10.dp, top = 10.dp, bottom = 4.dp),
                )
                items.take(5).forEach { conversation ->
                    ConversationRow(
                        conversation = conversation,
                        isActive = conversation.id == activeConversationId,
                        onClick = { onSelectConversation(conversation.id) },
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        DrawerAction(Icons.Filled.Star, stringResource(id = R.string.nav_history), onClick = onOpenHistory)
        DrawerAction(Icons.Filled.List, stringResource(id = R.string.nav_lab), onClick = onOpenLab)
        DrawerAction(Icons.Filled.Person, stringResource(id = R.string.nav_profile), onClick = onOpenProfile)
        DrawerAction(Icons.Filled.Settings, stringResource(id = R.string.nav_settings), onClick = onOpenSettings)
        DrawerAction(Icons.Filled.Info, stringResource(id = R.string.nav_about), onClick = onOpenAbout)

        // A área do Modo Deus só é mostrada quando o servidor informa que este
        // usuário é OWNER/ADMIN (resposta de /api/v1/me). Mesmo assim, quem
        // autoriza cada ação continua sendo o backend.
        if (identity?.role?.canSeeGodMode == true) {
            Spacer(Modifier.height(8.dp))
            DrawerAction(
                icon = Icons.Filled.Lock,
                label = stringResource(id = R.string.nav_god_mode),
                onClick = onOpenGodMode,
                highlighted = true,
            )
        }

        Spacer(Modifier.height(20.dp))

        Surface(
            color = colors.surfaceHigh,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NardekAvatar(size = 34.dp)
                Spacer(Modifier.size(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = identity?.displayName ?: stringResource(id = R.string.account_guest),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = identity?.let { "${it.role.id} · ${it.email ?: "—"}" }
                            ?: stringResource(id = R.string.account_signed_out),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textMuted,
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            text = stringResource(id = R.string.drawer_version),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textMuted,
        )
    }
}

/** Agrupa as conversas por dia, como pedido na V1 ("listagem por data"). */
private fun groupByDay(conversations: List<Conversation>): List<Pair<String, List<Conversation>>> {
    if (conversations.isEmpty()) return emptyList()
    val today = Calendar.getInstance()
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val format = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    fun labelFor(timestamp: Long): String {
        val calendar = Calendar.getInstance().apply { timeInMillis = timestamp }
        return when {
            sameDay(calendar, today) -> "Hoje"
            sameDay(calendar, yesterday) -> "Ontem"
            else -> format.format(Date(timestamp))
        }
    }

    return conversations
        .sortedByDescending { it.updatedAt }
        .groupBy { labelFor(it.updatedAt) }
        .map { (label, items) -> label to items }
}

private fun sameDay(a: Calendar, b: Calendar): Boolean =
    a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = LocalNardekColors.current.textMuted,
        modifier = Modifier.padding(start = 10.dp, bottom = 2.dp),
    )
}

@Composable
private fun DrawerAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    highlighted: Boolean = false,
) {
    Surface(
        color = if (highlighted) NardekPalette.Cyan.copy(alpha = 0.12f) else Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (highlighted) NardekPalette.Cyan else LocalNardekColors.current.textSecondary,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (highlighted) NardekPalette.Cyan else LocalNardekColors.current.textPrimary,
            )
        }
    }
}

@Composable
private fun ConversationRow(
    conversation: Conversation,
    isActive: Boolean,
    onClick: () -> Unit,
) {
    val colors = LocalNardekColors.current
    Surface(
        color = if (isActive) colors.surfaceHigh else Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp)
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(
                        if (isActive) NardekPalette.Cyan else colors.outline,
                        RoundedCornerShape(50),
                    ),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = conversation.title.ifBlank { stringResource(id = R.string.history_untitled) },
                style = MaterialTheme.typography.bodyMedium,
                color = if (isActive) colors.textPrimary else colors.textSecondary,
                maxLines = 1,
            )
        }
    }
}
