package com.nexia.app.memory

import com.nexia.app.data.remote.NardekBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Memória da NARDEK IA (V1).
 *
 * Cada conta tem a própria memória, guardada no servidor. Na V1 ela não entra
 * automaticamente no prompt do modelo: isso é ativado na V10, com controle de
 * privacidade — o usuário decide o que a IA pode lembrar.
 */
class MemoryRepository(
    private val backend: NardekBackend,
    private val tokenProvider: () -> String?,
) {

    data class Note(val content: String, val tag: String)

    suspend fun notes(): List<Note> = withContext(Dispatchers.IO) {
        val response = backend.get("/api/v1/memory", tokenProvider())
        if (!response.isOk) return@withContext emptyList()
        runCatching {
            val array = JSONObject(response.body).getJSONArray("notes")
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                Note(item.optString("content"), item.optString("tag"))
            }
        }.getOrDefault(emptyList())
    }

    suspend fun remember(content: String, tag: String = "geral"): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().put("content", content).put("tag", tag).toString()
        backend.put("/api/v1/memory", body, tokenProvider()).isOk
    }

    suspend fun forgetEverything(): Boolean = withContext(Dispatchers.IO) {
        backend.delete("/api/v1/memory", tokenProvider()).isOk
    }
}
