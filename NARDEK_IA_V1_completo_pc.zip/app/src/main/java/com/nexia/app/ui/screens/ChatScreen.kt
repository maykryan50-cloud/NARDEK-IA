package com.nexia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexia.app.R
import com.nexia.app.chat.ChatUiState
import com.nexia.app.domain.model.ChatRole
import com.nexia.app.ui.components.AssistantMessageBubble
import com.nexia.app.ui.components.MessageInputBar
import com.nexia.app.ui.components.NardekTopBar
import com.nexia.app.ui.components.TypingIndicator
import com.nexia.app.ui.components.UserMessageBubble
import com.nexia.app.ui.theme.LocalNardekColors
import com.nexia.app.ui.theme.NardekPalette

/**
 * Tela principal: conversa com a NARDEK IA.
 * Inclui seletor de modelo, indicador "IA digitando", botão de parar e
 * aviso de idioma configurado para as respostas.
 */
@Composable
fun ChatScreen(
    state: ChatUiState,
    onOpenDrawer: () -> Unit,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onSuggestionClick: (String) -> Unit,
    onAttachClick: () -> Unit,
    onModelSelected: (String) -> Unit,
    onNoticeShown: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    val listState = rememberLazyListState()
    val messages = state.messages
    var modelMenuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
        if (messages.isNotEmpty()) {
            runCatching { listState.scrollToItem(messages.lastIndex) }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        NardekTopBar(
            title = stringResource(id = R.string.app_name),
            subtitle = state.selectedModel?.name ?: state.engineLabel,
            onMenuClick = onOpenDrawer,
            showAvatar = true,
            trailing = {
                Box {
                    TextButton(onClick = { modelMenuOpen = true }) {
                        Text(
                            text = "▾ ${state.selectedModel?.name ?: "NARDEK"}",
                            style = MaterialTheme.typography.labelLarge,
                            color = NardekPalette.Cyan,
                        )
                    }
                    DropdownMenu(
                        expanded = modelMenuOpen,
                        onDismissRequest = { modelMenuOpen = false },
                        containerColor = colors.surfaceHigh,
                    ) {
                        state.models.forEach { model ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = model.name,
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = colors.textPrimary,
                                        )
                                        Text(
                                            text = model.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = colors.textMuted,
                                        )
                                    }
                                },
                                onClick = {
                                    onModelSelected(model.id)
                                    modelMenuOpen = false
                                },
                            )
                        }
                    }
                }
            },
        )

        if (state.notice != null) {
            Surface(
                color = NardekPalette.Warning.copy(alpha = 0.15f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNoticeShown() },
            ) {
                Text(
                    text = state.notice,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            if (messages.isEmpty() && !state.isGenerating) {
                EmptyConversationState(
                    engineLabel = state.engineLabel,
                    languageLabel = state.responseLanguageCode,
                    onSuggestionClick = onSuggestionClick,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                ) {
                    items(items = messages, key = { it.id }) { message ->
                        when (message.role) {
                            ChatRole.USER -> UserMessageBubble(message, Modifier.padding(bottom = 16.dp))
                            ChatRole.ASSISTANT -> AssistantMessageBubble(message, Modifier.padding(bottom = 16.dp))
                        }
                    }
                    if (state.isGenerating && messages.lastOrNull()?.isStreaming != true) {
                        item(key = "typing") { TypingIndicator(Modifier.padding(bottom = 16.dp)) }
                    }
                }
            }
        }

        MessageInputBar(
            value = state.input,
            isGenerating = state.isGenerating,
            onValueChange = onInputChange,
            onSend = onSend,
            onStop = onStop,
            onAttach = onAttachClick,
        )
    }
}

/** Tela inicial da conversa: marca + sugestões + estado do motor. */
@Composable
private fun EmptyConversationState(
    engineLabel: String,
    languageLabel: String,
    onSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalNardekColors.current
    Column(
        modifier = modifier.padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        com.nexia.app.ui.components.NardekBrandBlock(symbolSize = 90.dp)
        Spacer(Modifier.height(20.dp))

        Surface(
            color = colors.surfaceHigh,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, colors.outline),
        ) {
            Text(
                text = "$engineLabel · ${stringResource(id = R.string.chat_language_label)}: $languageLabel",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }

        Spacer(Modifier.height(18.dp))
        Text(
            text = stringResource(id = R.string.chat_empty_title),
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(12.dp))

        listOf(
            stringResource(id = R.string.suggestion_1),
            stringResource(id = R.string.suggestion_2),
            stringResource(id = R.string.suggestion_3),
            stringResource(id = R.string.suggestion_4),
        ).forEach { suggestion ->
            Surface(
                color = colors.surfaceHigh,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, colors.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clickable { onSuggestionClick(suggestion) },
            ) {
                Text(
                    text = suggestion,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                )
            }
        }
    }
}
