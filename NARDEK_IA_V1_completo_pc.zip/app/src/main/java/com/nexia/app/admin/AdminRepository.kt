package com.nexia.app.admin

import com.nexia.app.data.remote.NardekBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Painel Modo Deus — lado do aplicativo.
 *
 * Este repositório apenas CHAMA o backend. Cada resposta 403/401 vem do servidor:
 * é ele que decide se o usuário pode ver ou alterar algo. Mesmo que alguém
 * modificasse o APK para forçar a abertura desta tela, o servidor continuaria
 * negando as operações de quem não é OWNER.
 */
class AdminRepository(
    private val backend: NardekBackend,
    private val tokenProvider: () -> String?,
) {

    data class Result<T>(
        val data: T? = null,
        val error: String? = null,
        val forbidden: Boolean = false,
    ) {
        val isOk: Boolean get() = data != null && error == null
    }

    data class Overview(
        val environment: String,
        val aiProvider: String,
        val aiKeyConfigured: Boolean,
        val knownUsers: Int,
        val owners: Int,
        val admins: Int,
        val blocked: Int,
        val messagesToday: Int,
        val costTodayUsd: Double,
        val budgetUsd: Double,
        val killSwitch: Boolean,
        val myRole: String,
        val permissions: List<String>,
    )

    data class UserRow(
        val uid: String,
        val email: String?,
        val displayName: String,
        val role: String,
        val blocked: Boolean,
        val dailyMessageLimit: Int?,
        val messagesToday: Int,
        val costTodayUsd: Double,
    )

    data class AuditRow(
        val id: Int,
        val actor: String,
        val action: String,
        val target: String?,
        val detail: String,
        val createdAt: Long,
    )

    suspend fun overview(): Result<Overview> = withContext(Dispatchers.IO) { call("/api/v1/admin/overview") { json ->
        val server = json.getJSONObject("server")
        val people = json.getJSONObject("people")
        val today = json.getJSONObject("today")
        val flags = json.getJSONObject("flags")
        val you = json.getJSONObject("you")
        Overview(
            environment = server.optString("env"),
            aiProvider = server.optString("ai_provider"),
            aiKeyConfigured = server.optBoolean("ai_key_configured"),
            knownUsers = people.optInt("known_users"),
            owners = people.optInt("owners"),
            admins = people.optInt("admins"),
            blocked = people.optInt("blocked"),
            messagesToday = today.optInt("messages"),
            costTodayUsd = today.optDouble("cost_usd", 0.0),
            budgetUsd = today.optDouble("budget_usd", 0.0),
            killSwitch = flags.optBoolean("kill_switch"),
            myRole = you.optString("role"),
            permissions = you.optJSONArray("permissions")?.let { array ->
                List(array.length()) { index -> array.optString(index) }
            } ?: emptyList(),
        )
    } }

    suspend fun users(query: String? = null): Result<List<UserRow>> = withContext(Dispatchers.IO) {
        val path = if (query.isNullOrBlank()) "/api/v1/admin/users" else "/api/v1/admin/users?query=$query"
        val response = backend.get(path, tokenProvider())
        val parsed = runCatching {
            val array = org.json.JSONArray(response.body)
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                UserRow(
                    uid = item.optString("uid"),
                    email = item.optString("email").ifBlank { null },
                    displayName = item.optString("display_name"),
                    role = item.optString("role"),
                    blocked = item.optBoolean("blocked"),
                    dailyMessageLimit = if (item.isNull("daily_message_limit")) null else item.optInt("daily_message_limit"),
                    messagesToday = item.optInt("messages_today"),
                    costTodayUsd = item.optDouble("cost_today_usd", 0.0),
                )
            }
        }.getOrNull()

        if (parsed == null) failure(response) else Result(data = parsed)
    }

    suspend fun updateUser(
        uid: String,
        role: String? = null,
        blocked: Boolean? = null,
        dailyMessageLimit: Int? = null,
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val body = JSONObject()
        role?.let { body.put("role", it) }
        blocked?.let { body.put("blocked", it) }
        dailyMessageLimit?.let { body.put("daily_message_limit", it) }
        val response = backend.patch("/api/v1/admin/users/$uid", body.toString(), tokenProvider())
        if (response.isOk) Result(data = true) else failure(response)
    }

    suspend fun audit(): Result<List<AuditRow>> = withContext(Dispatchers.IO) { call("/api/v1/admin/audit") { json ->
        val array = json.getJSONArray("entries")
        List(array.length()) { index ->
            val item = array.getJSONObject(index)
            AuditRow(
                id = item.optInt("id"),
                actor = item.optString("actor"),
                action = item.optString("action"),
                target = item.optString("target").ifBlank { null },
                detail = item.optString("detail"),
                createdAt = (item.optDouble("created_at", 0.0) * 1000).toLong(),
            )
        }
    } }

    suspend fun setKillSwitch(enabled: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        val body = JSONObject().put("kill_switch", enabled).toString()
        val response = backend.patch("/api/v1/admin/settings", body, tokenProvider())
        if (response.isOk) Result(data = true) else failure(response)
    }

    suspend fun runTool(tool: String): Result<String> = withContext(Dispatchers.IO) {
        val response = backend.post("/api/v1/admin/tools/$tool", "{}", tokenProvider())
        if (response.isOk) {
            Result(data = runCatching { JSONObject(response.body).optString("result") }.getOrElse { response.body })
        } else failure(response)
    }

    // ------------------------------------------------------------------ utils

    private fun <T> call(path: String, parse: (JSONObject) -> T): Result<T> {
        val response = backend.get(path, tokenProvider())
        if (!response.isOk) return failure(response)
        val json = runCatching { JSONObject(response.body) }.getOrNull()
            ?: return Result(error = "Resposta inesperada do servidor.")
        return try {
            Result(data = parse(json))
        } catch (error: Exception) {
            Result(error = error.message ?: "Falha ao interpretar a resposta do servidor.")
        }
    }

    private fun failure(response: NardekBackend.Result): Result<Nothing> {
        val detail = runCatching { JSONObject(response.body).optString("detail") }.getOrNull().orEmpty()
        return Result(
            error = when {
                response.networkError != null -> "Sem conexão com o servidor: ${response.networkError}"
                response.statusCode == 403 -> detail.ifBlank { "Acesso negado pelo servidor (403)." }
                response.statusCode == 401 -> "Sessão inválida ou expirada."
                else -> detail.ifBlank { "Erro HTTP ${response.statusCode}." }
            },
            forbidden = response.statusCode == 403,
        )
    }
}
