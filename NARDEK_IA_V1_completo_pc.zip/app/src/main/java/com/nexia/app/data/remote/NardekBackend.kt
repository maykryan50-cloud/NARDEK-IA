package com.nexia.app.data.remote

import com.nexia.app.BuildConfig
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente HTTP do backend NARDEK IA.
 *
 * Usa apenas as bibliotecas já presentes no Android (HttpURLConnection + org.json),
 * então o aplicativo não carrega dependência extra nenhuma para falar com o servidor.
 *
 * O app NUNCA conversa com o provedor de IA diretamente: todas as chamadas
 * passam por aqui, e o token de sessão vai no cabeçalho Authorization.
 */
class NardekBackend(
    val baseUrl: String = BuildConfig.NARDEK_BACKEND_URL,
) {

    data class Result(
        val statusCode: Int,
        val body: String,
        val networkError: String? = null,
    ) {
        val isOk: Boolean get() = networkError == null && statusCode in 200..299
    }

    fun get(path: String, token: String? = null): Result = request("GET", path, null, token)

    fun post(path: String, json: String, token: String? = null): Result = request("POST", path, json, token)

    fun put(path: String, json: String, token: String? = null): Result = request("PUT", path, json, token)

    fun patch(path: String, json: String, token: String? = null): Result = request("PATCH", path, json, token)

    fun delete(path: String, token: String? = null): Result = request("DELETE", path, null, token)

    private fun request(method: String, path: String, body: String?, token: String?): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 10_000
                readTimeout = 60_000
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-Nardek-Client", "android/${BuildConfig.VERSION_NAME}")
                if (!token.isNullOrBlank()) {
                    setRequestProperty("Authorization", "Bearer $token")
                }
                if (body != null) {
                    doOutput = true
                    outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
            }

            val code = connection.responseCode
            val stream: InputStream = if (code in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream ?: connection.inputStream
            }
            Result(statusCode = code, body = stream?.let(::readAll) ?: "")
        } catch (error: Exception) {
            Result(
                statusCode = 0,
                body = "",
                networkError = error.message ?: error.javaClass.simpleName,
            )
        } finally {
            connection?.disconnect()
        }
    }

    private fun readAll(stream: InputStream): String =
        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
}
