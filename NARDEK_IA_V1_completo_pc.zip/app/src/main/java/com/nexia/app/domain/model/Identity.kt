package com.nexia.app.domain.model

/**
 * Papel do usuário na NARDEK IA.
 *
 * ATENÇÃO: este enum existe apenas para a INTERFACE decidir o que mostrar.
 * Quem autoriza de verdade é o backend — a cada chamada, o servidor revalida.
 * Esconder ou mostrar um botão nunca substitui a permissão do servidor.
 */
enum class Role(val id: String) {
    USER("USER"),
    ADMIN("ADMIN"),
    OWNER("OWNER");

    val canSeeGodMode: Boolean get() = this == ADMIN || this == OWNER

    companion object {
        fun fromId(id: String?): Role = entries.firstOrNull { it.id == id?.uppercase() } ?: USER
    }
}

/** Identidade do usuário, do jeito que o servidor devolve em /api/v1/me. */
data class Identity(
    val uid: String,
    val email: String?,
    val displayName: String,
    val role: Role,
    val permissions: List<String> = emptyList(),
    val godMode: Boolean = false,
)

/** Limites reais informados pelo servidor (não são decididos pelo app). */
data class UsageLimits(
    val dailyMessagesUsed: Int = 0,
    val dailyMessagesLimit: Int = 0,
    val dailyCostUsedUsd: Double = 0.0,
    val dailyCostLimitUsd: Double = 0.0,
    val globalCostUsedUsd: Double = 0.0,
    val globalCostLimitUsd: Double = 0.0,
)
