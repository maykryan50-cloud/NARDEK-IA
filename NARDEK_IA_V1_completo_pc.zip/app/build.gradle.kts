plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    // V3 (Firebase Authentication): descomentar junto com o google-services.json
    // id("com.google.gms.google-services") version "4.4.2"
}

android {
    namespace = "com.nexia.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexia.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.1.0-v1"

        vectorDrawables { useSupportLibrary = true }

        // ----------------------------------------------------------------
        // Valores de BUILD. Nenhum deles é segredo:
        //   * URL do backend  → endereço público do servidor
        //   * Web Client ID   → identificador público do Google Sign-In
        // Chaves de API e permissões do Modo Deus NUNCA entram aqui: ficam
        // no backend, que é quem autoriza tudo.
        // ----------------------------------------------------------------
        // Emulador Android usa 10.0.2.2 para alcançar a máquina que roda o backend.
        // Em celular físico, troque pelo IP do computador na mesma rede Wi-Fi
        // (ex.: "http://192.168.0.10:8000").
        buildConfigField("String", "NARDEK_BACKEND_URL", "\"http://10.0.2.2:8000\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID",
            "\"77206442214-7u96thvm1d0rlne3si127kddm191st65.apps.googleusercontent.com\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"nardek-ia\"")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    // --- Base ---
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // --- Jetpack Compose ---
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    // --- Navegação ---
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // --- Testes ---
    testImplementation("junit:junit:4.13.2")

    // --- Debug ---
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    // A V3 acrescenta aqui: firebase-bom, firebase-auth-ktx,
    // credential-manager e googleid (Google Sign-In). Só depois do
    // google-services.json + SHA-1 cadastrados no Firebase.
}
