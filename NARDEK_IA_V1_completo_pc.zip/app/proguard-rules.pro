# Regras ProGuard/R8 da NARDEK IA
# A V1 não usa minificação (isMinifyEnabled = false).
# Estas regras já ficam prontas para quando o release assinado for gerado.

# Mantém as classes de modelo usadas em (futura) serialização
-keep class com.nexia.app.data.model.** { *; }

# Compose
-dontwarn androidx.compose.**

# OkHttp/Retrofit (V2)
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
