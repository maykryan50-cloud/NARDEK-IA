#!/usr/bin/env bash
# ============================================================
#  NARDEK IA — publicar no GitHub (caminho do computador)
#
#  Como usar:
#    1. descompacte o ZIP do projeto
#    2. dê permissão e rode:   chmod +x publicar.sh && ./publicar.sh
#    3. quando o Git pedir senha, use um TOKEN do GitHub
#       (não use a senha da conta — o GitHub não aceita mais)
#
#  Criar o token: github.com → foto → Settings → Developer settings
#    → Personal access tokens → Fine-grained tokens → Generate new token
#    → Repository access: apenas NARDEK-IA
#    → Permissions: Contents = Read and write
#  Copie o token (aparece uma única vez) e cole quando o Git pedir.
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

REPO="https://github.com/maykryan50-cloud/NARDEK-IA.git"

echo "==> 1/6 Conferindo segurança (nada sensível pode subir)"
for arquivo in backend/.env app/google-services.json local.properties; do
  if [ -f "$arquivo" ]; then
    echo "    encontrado: $arquivo (será ignorado pelo .gitignore)"
  fi
done
if ls ./*.jks ./*.keystore >/dev/null 2>&1; then
  echo "    encontrado: chave de assinatura (será ignorada)"
fi

echo "==> 2/6 Iniciando repositório local"
git init -b main >/dev/null 2>&1 || git init >/dev/null

echo "==> 3/6 Adicionando arquivos"
git add -A
git diff --cached --quiet && echo "    nada novo para commitar" || git commit -m "NARDEK IA V1 — esqueleto modular (Kotlin/Compose + FastAPI)"

echo "==> 4/6 Conferindo se algum segredo entrou por engano"
if git ls-files | grep -E '(^|/)\.env$|\.jks$|\.keystore$|google-services\.json$|local\.properties$'; then
  echo "    ERRO: segredo na lista de arquivos. NÃO continue. Aviso o desenvolvedor."
  exit 1
fi
echo "    ok: nenhum segredo versionado ✔"

echo "==> 5/6 Conectando ao repositório"
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO"

echo "==> 6/6 Enviando para a branch main"
echo "    (quando o Git pedir:"
echo "       Username: maykryan50-cloud"
echo "       Password: cole o TOKEN do GitHub )"
git push -u origin main

echo
echo "Pronto! Agora no GitHub: aba Actions → 'NARDEK IA — APK' → Run workflow"
echo "Quando ficar verde, o APK está em Artifacts → nardek-apk-debug"
