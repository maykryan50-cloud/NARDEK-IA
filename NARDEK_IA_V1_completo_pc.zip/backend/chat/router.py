"""Rotas do chat da NARDEK IA."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from auth.dependencies import get_current_user
from auth.service import Identity
from chat.schemas import ChatRequest, ChatResponse
from chat.service import handle_chat
from models.catalog import available_for
from services import languages

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(payload: ChatRequest, user: Identity = Depends(get_current_user)) -> ChatResponse:
    """
    Conversa com a IA.

    A V1 responde com o provedor de desenvolvimento; ao configurar a chave do
    provedor no servidor (.env), a mesma rota passa a devolver a resposta real,
    sem alteração no aplicativo.
    """
    return await handle_chat(payload, user)


@router.get("/models")
async def models(user: Identity = Depends(get_current_user)) -> dict:
    """Modelos disponíveis para o papel deste usuário."""
    return {
        "models": [
            {
                "id": spec.id,
                "name": spec.name,
                "description": spec.description,
                "supports_vision": spec.supports_vision,
                "supports_web": spec.supports_web,
                "context_tokens": spec.context_tokens,
            }
            for spec in available_for(user.role)
        ]
    }


@router.get("/languages")
async def supported_languages() -> dict:
    """Idiomas que a IA pode responder, incluindo a opção automática."""
    return {"languages": languages.catalog()}
