"""
Regras de negócio do chat.

Fluxo de um pedido:
  1. valida o modelo contra o catálogo e o papel do usuário,
  2. resolve o idioma da resposta,
  3. aplica os limites reais (services/limits.py),
  4. chama o provedor (services/ai_provider.py) — a chave nunca sai daqui,
  5. registra consumo e devolve a resposta.
"""
from __future__ import annotations

import uuid

from fastapi import HTTPException, status

from auth.roles import at_least
from auth.service import Identity
from chat.schemas import ChatLimits, ChatRequest, ChatResponse, ChatUsage
from models.catalog import ModelSpec, find
from services import languages, limits
from services.ai_provider import get_provider
from services.settings import get_settings

SYSTEM_PROMPT_BASE = (
    "Você é a NARDEK IA, assistente criada para o aplicativo NARDEK. "
    "Responda de forma objetiva, correta e cordial. "
    "Nunca invente dados; se não souber, diga que não sabe."
)


def resolve_model(model_id: str, user: Identity) -> ModelSpec:
    spec = find(model_id)
    if spec is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Modelo '{model_id}' não existe.")
    if not spec.enabled:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"O modelo '{spec.name}' ainda não está ativo nesta versão.",
        )
    if not at_least(user.role, spec.min_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"O modelo '{spec.name}' exige o papel {spec.min_role.value}.",
        )
    return spec


def estimate_cost(spec: ModelSpec, message: str, history_len: int) -> float:
    """Estimativa antes de gastar: usada para checar o orçamento."""
    approx_in = (len(message) // 4) + (history_len * 60)
    return round((approx_in / 1000) * spec.cost_per_1k_in, 6)


def system_prompt_for(language_code: str) -> str:
    override = limits.STORE.settings_overrides.get("ai.system_prompt")
    base = override or SYSTEM_PROMPT_BASE
    temperature_note = ""
    if limits.STORE.settings_overrides.get("ai.style") == "direto":
        temperature_note = " Seja ainda mais conciso."
    return f"{base}{temperature_note}\n\n{languages.instruction_for(language_code)}"


async def handle_chat(payload: ChatRequest, user: Identity) -> ChatResponse:
    settings = get_settings()
    spec = resolve_model(payload.model, user)

    language_code = languages.resolve(payload.response_language, payload.message)
    language_auto = not payload.response_language or payload.response_language.strip().lower() == languages.AUTO

    try:
        limits.enforce_before_request(user, estimate_cost(spec, payload.message, len(payload.history)))
    except limits.LimitExceeded as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(exc),
            headers={"X-Nardek-Limit": exc.scope, "Retry-After": str(exc.retry_after_seconds)},
        ) from exc

    provider = get_provider()
    max_tokens = int(limits.STORE.settings_overrides.get("ai.max_tokens", "1024"))
    temperature = float(limits.STORE.settings_overrides.get("ai.temperature", "0.7"))

    reply = await provider.complete(
        system_prompt=system_prompt_for(language_code),
        user_message=payload.message,
        history=[{"role": item.role, "content": item.content} for item in payload.history],
        model_name=spec.id,
        temperature=temperature,
        max_tokens=max_tokens,
    )

    cost = round(
        (reply.tokens_in / 1000) * spec.cost_per_1k_in + (reply.tokens_out / 1000) * spec.cost_per_1k_out,
        6,
    )
    usage = limits.register_usage(user, tokens_in=reply.tokens_in, tokens_out=reply.tokens_out, cost_usd=cost)
    current = limits.status_for(user)

    return ChatResponse(
        conversation_id=payload.conversation_id or f"conv-{uuid.uuid4().hex[:12]}",
        reply=reply.text,
        model=spec.id,
        model_name=spec.name,
        language=language_code,
        language_auto=language_auto,
        usage=ChatUsage(
            tokens_in=reply.tokens_in,
            tokens_out=reply.tokens_out,
            cost_usd=cost,
            provider=reply.provider or settings.ai_provider,
        ),
        limits=ChatLimits(
            daily_messages_used=usage.messages,
            daily_messages_limit=current.daily_messages_limit,
            daily_cost_used_usd=round(usage.cost_usd, 4),
            daily_cost_limit_usd=current.daily_cost_limit_usd,
        ),
    )
