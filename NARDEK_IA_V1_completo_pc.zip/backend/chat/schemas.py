"""Contratos (schemas) do chat da NARDEK IA."""
from __future__ import annotations

from pydantic import BaseModel, Field


class HistoryItem(BaseModel):
    role: str = Field(..., pattern="^(user|assistant)$")
    content: str


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=8000)
    conversation_id: str | None = Field(None, description="Identificador da conversa no app")
    model: str = Field("nardek", description="id do modelo (ver /api/v1/chat/models)")
    response_language: str = Field(
        "auto",
        description="'auto' = responder no idioma da mensagem, ou um código como pt-BR/en-US",
    )
    history: list[HistoryItem] = Field(default_factory=list, max_length=40)


class ChatUsage(BaseModel):
    tokens_in: int
    tokens_out: int
    cost_usd: float
    provider: str


class ChatLimits(BaseModel):
    daily_messages_used: int
    daily_messages_limit: int
    daily_cost_used_usd: float
    daily_cost_limit_usd: float


class ChatResponse(BaseModel):
    conversation_id: str
    reply: str
    model: str
    model_name: str
    language: str
    language_auto: bool
    usage: ChatUsage
    limits: ChatLimits
