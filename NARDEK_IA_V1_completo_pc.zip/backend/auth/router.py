"""
Rotas de autenticação.

  POST /api/v1/auth/dev-login  → login de teste (só existe fora de produção)
  GET  /api/v1/auth/providers  → quais provedores estão disponíveis neste servidor
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from auth.roles import Role, permissions_for, role_from_email_or_uid
from auth.service import issue_dev_token
from services.settings import get_settings

router = APIRouter(prefix="/auth", tags=["auth"])


class DevLoginRequest(BaseModel):
    email: str = Field(..., description="E-mail de teste (usado para definir o papel inicial)")
    display_name: str = Field("Usuário NARDEK", max_length=60)


class DevLoginResponse(BaseModel):
    access_token: str
    token_type: str = "Bearer"
    expires_at: int
    uid: str
    email: str | None
    role: Role
    permissions: list[str]


@router.post("/dev-login", response_model=DevLoginResponse)
async def dev_login(payload: DevLoginRequest) -> DevLoginResponse:
    """
    Emite um token de desenvolvimento.

    Em produção este endpoint responde 404 — o login passa a ser o Firebase
    Authentication (Google), validado no servidor. O papel continua sendo
    decidido aqui, pelas listas OWNER_/ADMIN_ configuradas no servidor.
    """
    settings = get_settings()
    if not settings.dev_auth_enabled:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Login de desenvolvimento desativado neste servidor.",
        )

    email = payload.email.strip().lower()
    uid = f"dev-{abs(hash(email)) % 10**10}"
    role = role_from_email_or_uid(email, uid)
    token, expires_at = issue_dev_token(uid, email, payload.display_name)

    return DevLoginResponse(
        access_token=token,
        expires_at=expires_at,
        uid=uid,
        email=email,
        role=role,
        permissions=permissions_for(role),
    )


@router.get("/providers")
async def providers() -> dict:
    """Informa o que este servidor aceita. Nenhum segredo é exposto."""
    settings = get_settings()
    return {
        "google_sign_in": True,
        "firebase_project_id": settings.firebase_project_id,
        "dev_login": settings.dev_auth_enabled,
        "auth_mode": settings.auth_mode,
    }
