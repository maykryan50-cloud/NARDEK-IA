"""
Papéis e permissões da NARDEK IA.

O servidor é a ÚNICA fonte de verdade. O aplicativo pode esconder botões,
mas quem autoriza (ou nega) cada ação é este módulo, via dependências FastAPI.
"""
from __future__ import annotations

from enum import StrEnum


class Role(StrEnum):
    USER = "USER"      # usuário comum
    ADMIN = "ADMIN"    # equipe: acessa painel, não muda papéis
    OWNER = "OWNER"    # dono: Modo Deus completo


#: Hierarquia numérica (quanto maior, mais poder).
_WEIGHT: dict[Role, int] = {Role.USER: 0, Role.ADMIN: 1, Role.OWNER: 2}


class Permission(StrEnum):
    CHAT_USE = "chat.use"
    MODELS_LIST = "models.list"
    MEMORY_READ = "memory.read"
    MEMORY_WRITE = "memory.write"

    ADMIN_PANEL = "admin.panel"          # ver o painel
    ADMIN_USERS_VIEW = "admin.users.view"
    ADMIN_MODELS_VIEW = "admin.models.view"
    ADMIN_AUDIT_VIEW = "admin.audit.view"
    ADMIN_TOOLS = "admin.tools"

    GOD_USERS_MANAGE = "god.users.manage"      # mudar papel/bloquear usuário
    GOD_MODELS_MANAGE = "god.models.manage"    # catálogo e modelo padrão
    GOD_SETTINGS_MANAGE = "god.settings.manage"
    GOD_LIMITS_MANAGE = "god.limits.manage"
    GOD_KILL_SWITCH = "god.kill_switch"


_GRANTS: dict[Role, frozenset[Permission]] = {
    Role.USER: frozenset({
        Permission.CHAT_USE,
        Permission.MODELS_LIST,
        Permission.MEMORY_READ,
        Permission.MEMORY_WRITE,
    }),
    Role.ADMIN: frozenset({
        Permission.CHAT_USE,
        Permission.MODELS_LIST,
        Permission.MEMORY_READ,
        Permission.MEMORY_WRITE,
        Permission.ADMIN_PANEL,
        Permission.ADMIN_USERS_VIEW,
        Permission.ADMIN_MODELS_VIEW,
        Permission.ADMIN_AUDIT_VIEW,
        Permission.ADMIN_TOOLS,
    }),
    Role.OWNER: frozenset({p for p in Permission}),  # dono: tudo
}


def permissions_for(role: Role) -> list[str]:
    return sorted(p.value for p in _GRANTS.get(role, frozenset()))


def role_has(role: Role, permission: Permission) -> bool:
    return permission in _GRANTS.get(role, frozenset())


def at_least(role: Role, minimum: Role) -> bool:
    return _WEIGHT.get(role, 0) >= _WEIGHT.get(minimum, 0)


def role_from_email_or_uid(email: str | None, uid: str | None) -> Role:
    """
    Define o papel inicial de uma identidade.

    Regra de ouro: papéis privilegiados vêm SEMPRE da configuração do servidor
    (OWNER_EMAILS / OWNER_UIDS / ADMIN_EMAILS / ADMIN_UIDS), nunca de dados
    enviados pelo aplicativo.
    """
    from services.settings import get_settings  # import local evita ciclo

    settings = get_settings()
    if settings.email_is_owner(email) or settings.uid_is_owner(uid):
        return Role.OWNER
    if settings.email_is_admin(email) or settings.uid_is_admin(uid):
        return Role.ADMIN
    return Role.USER
