"""
Serviço de identidade.

Modo `dev`      → tokens HMAC assinados por este servidor (apenas fora de produção).
Modo `firebase` → valida o ID token do Firebase/Google (RS256, JWKS do Google).

Em qualquer modo, o PAPEL do usuário é calculado aqui, no servidor, a partir da
configuração de ambiente — nunca a partir do que o aplicativo afirma ser.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass

from auth.roles import Role, role_from_email_or_uid
from services.settings import get_settings


class AuthError(Exception):
    """Token ausente, inválido ou expirado."""


@dataclass(frozen=True)
class Identity:
    uid: str
    email: str | None
    display_name: str
    role: Role
    provider: str  # "dev" | "google"


# --------------------------------------------------------------------------- #
#  Helpers de base64url / assinatura
# --------------------------------------------------------------------------- #

def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _b64d(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def _sign(payload: str, secret: str) -> str:
    digest = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest()
    return _b64e(digest)


# --------------------------------------------------------------------------- #
#  Tokens de desenvolvimento (HMAC)
# --------------------------------------------------------------------------- #

def issue_dev_token(uid: str, email: str | None, display_name: str) -> tuple[str, int]:
    """Cria um token de teste. Só é emitido quando AUTH_MODE=dev (não produção)."""
    settings = get_settings()
    expires_at = int(time.time()) + settings.token_ttl_hours * 3600
    body = {
        "sub": uid,
        "email": (email or "").lower() or None,
        "name": display_name,
        "iss": "nardek-dev",
        "exp": expires_at,
    }
    payload = _b64e(json.dumps(body, separators=(",", ":")).encode())
    return f"{payload}.{_sign(payload, settings.secret_key)}", expires_at


def _verify_dev_token(token: str) -> dict:
    settings = get_settings()
    try:
        payload, signature = token.split(".")
    except ValueError as exc:
        raise AuthError("Token malformado.") from exc

    if not hmac.compare_digest(signature, _sign(payload, settings.secret_key)):
        raise AuthError("Assinatura do token inválida.")

    try:
        body = json.loads(_b64d(payload))
    except (ValueError, json.JSONDecodeError) as exc:
        raise AuthError("Conteúdo do token inválido.") from exc

    if int(body.get("exp", 0)) < int(time.time()):
        raise AuthError("Token expirado.")
    return body


# --------------------------------------------------------------------------- #
#  Tokens do Firebase (Google) — ligados na V3
# --------------------------------------------------------------------------- #

def _verify_firebase_token(token: str) -> dict:
    """
    Valida um ID token do Firebase Authentication.

    Implementação real esperada: verificar assinatura RS256 contra o JWKS
    do Google e checar `aud == FIREBASE_PROJECT_ID` e `iss ==
    https://securetoken.google.com/<project>`. Enquanto a V3 não entra, o
    servidor recusa tokens do Firebase com mensagem clara, em vez de aceitar
    qualquer coisa (nunca confiar sem verificar).
    """
    raise AuthError(
        "Verificação de token do Firebase ainda não foi ativada neste servidor "
        "(etapa V3). Configure AUTH_MODE=dev para testes locais."
    )


# --------------------------------------------------------------------------- #
#  API pública do serviço
# --------------------------------------------------------------------------- #

def authenticate(token: str | None) -> Identity:
    """Transforma um token Bearer em uma identidade com papel definido pelo servidor."""
    if not token:
        raise AuthError("Token de autenticação ausente no cabeçalho Authorization.")

    settings = get_settings()
    if settings.auth_mode == "firebase":
        claims = _verify_firebase_token(token)
        provider = "google"
    else:
        claims = _verify_dev_token(token)
        provider = "dev"

    uid = str(claims.get("sub") or claims.get("user_id") or "").strip()
    email = (claims.get("email") or None)
    display_name = claims.get("name") or (email.split("@")[0] if email else "Usuário NARDEK")

    if not uid:
        raise AuthError("Token sem identificador de usuário.")

    return Identity(
        uid=uid,
        email=email,
        display_name=display_name,
        role=role_from_email_or_uid(email, uid),
        provider=provider,
    )
