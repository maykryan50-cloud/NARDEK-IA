"""Dependências FastAPI de autenticação e autorização."""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status

from auth.roles import Permission, Role, at_least, role_has
from auth.service import AuthError, Identity, authenticate
from services.store import STORE


def _bearer_token(request: Request) -> str | None:
    header = request.headers.get("Authorization", "")
    if header.lower().startswith("bearer "):
        return header[7:].strip()
    return None


async def get_current_user(request: Request) -> Identity:
    """Usuário autenticado. Sem token válido → 401."""
    try:
        identity = authenticate(_bearer_token(request))
    except AuthError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc),
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    # O servidor mantém o registro de quem já se autenticou (base do painel
    # Modo Deus). Aqui o papel também é reavaliado a cada requisição: se o
    # proprietário mudar o papel de alguém, vale imediatamente.
    record = STORE.upsert_user(
        uid=identity.uid,
        email=identity.email,
        display_name=identity.display_name,
        role=identity.role.value,
        provider=identity.provider,
    )
    if record.role != identity.role.value:
        identity = Identity(
            uid=identity.uid,
            email=identity.email,
            display_name=identity.display_name,
            role=Role(record.role),
            provider=identity.provider,
        )
    return identity


def require_role(minimum: Role):
    """Exige um papel mínimo (USER < ADMIN < OWNER). Verificado no servidor."""

    async def _dependency(user: Identity = Depends(get_current_user)) -> Identity:
        if not at_least(user.role, minimum):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Ação restrita. Seu papel ({user.role.value}) não autoriza este recurso.",
            )
        return user

    return _dependency


def require_permission(permission: Permission):
    """Exige uma permissão específica do mapa de papéis."""

    async def _dependency(user: Identity = Depends(get_current_user)) -> Identity:
        if not role_has(user.role, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permissão ausente: {permission.value}.",
            )
        return user

    return _dependency
