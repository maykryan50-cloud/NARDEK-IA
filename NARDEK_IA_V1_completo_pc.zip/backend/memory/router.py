"""
Memória da NARDEK IA (V1).

Cada usuário tem suas próprias anotações de memória. Nesta versão elas ficam na
memória do processo; na V4 passam para banco de dados sem mudar estas rotas.
Sempre por usuário: ninguém lê a memória de outra conta.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from auth.dependencies import require_permission
from auth.roles import Permission
from auth.service import Identity

router = APIRouter(prefix="/memory", tags=["memory"])

_NOTES: dict[str, list[dict]] = {}


class NoteIn(BaseModel):
    content: str = Field(..., min_length=1, max_length=2000)
    tag: str = Field("geral", max_length=40)


@router.get("")
async def read_memory(user: Identity = Depends(require_permission(Permission.MEMORY_READ))) -> dict:
    """Lista o que a NARDEK lembra sobre este usuário."""
    return {"notes": _NOTES.get(user.uid, []), "count": len(_NOTES.get(user.uid, []))}


@router.put("")
async def write_memory(
    note: NoteIn,
    user: Identity = Depends(require_permission(Permission.MEMORY_WRITE)),
) -> dict:
    """Adiciona uma anotação à memória do usuário."""
    notes = _NOTES.setdefault(user.uid, [])
    notes.append({"content": note.content, "tag": note.tag})
    del notes[:-100]  # guarda no máximo 100 anotações por usuário
    return {"count": len(notes)}


@router.delete("")
async def clear_memory(user: Identity = Depends(require_permission(Permission.MEMORY_WRITE))) -> dict:
    """Apaga toda a memória deste usuário (privacidade)."""
    _NOTES.pop(user.uid, None)
    return {"count": 0, "deleted": True}
