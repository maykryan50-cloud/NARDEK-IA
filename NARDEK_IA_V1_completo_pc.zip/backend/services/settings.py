"""Configuração do servidor: tudo por variável de ambiente (arquivo .env)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _load_env_file() -> None:
    """Lê backend/.env sem depender de python-dotenv."""
    env_file = Path(__file__).resolve().parent.parent / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file()


def _csv(name: str) -> frozenset[str]:
    raw = os.getenv(name, "")
    return frozenset(item.strip().lower() for item in raw.split(",") if item.strip())


def _int(name: str, default: int) -> int:
    try:
        return int(float(os.getenv(name, str(default))))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "NARDEK IA API")
    api_version: str = "v1"
    env: str = os.getenv("APP_ENV", "development").lower()
    auth_mode: str = os.getenv("AUTH_MODE", "dev").lower()  # dev | firebase
    secret_key: str = os.getenv("SECRET_KEY", "nardek-dev-secret-change-me")
    firebase_project_id: str = os.getenv("FIREBASE_PROJECT_ID", "nardek-ia")
    token_ttl_hours: int = _int("TOKEN_TTL_HOURS", 720)

    # Quem é dono do sistema (Modo Deus). Somente isto vira OWNER.
    owner_emails: frozenset[str] = field(default_factory=lambda: _csv("OWNER_EMAILS"))
    owner_uids: frozenset[str] = field(default_factory=lambda: _csv("OWNER_UIDS"))
    admin_emails: frozenset[str] = field(default_factory=lambda: _csv("ADMIN_EMAILS"))
    admin_uids: frozenset[str] = field(default_factory=lambda: _csv("ADMIN_UIDS"))

    # Provedor de IA (segredo somente no servidor)
    ai_provider: str = os.getenv("AI_PROVIDER", "mock").lower()  # mock | openai
    ai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    ai_base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    ai_timeout_seconds: float = _float("AI_TIMEOUT_SECONDS", 60.0)

    # Limites reais de uso (o servidor impõe; o app não decide nada)
    daily_messages_user: int = _int("LIMIT_USER_DAILY_MESSAGES", 50)
    daily_messages_admin: int = _int("LIMIT_ADMIN_DAILY_MESSAGES", 1000)
    daily_messages_owner: int = _int("LIMIT_OWNER_DAILY_MESSAGES", 10000)
    daily_cost_user: float = _float("LIMIT_USER_DAILY_COST_USD", 0.50)
    daily_cost_admin: float = _float("LIMIT_ADMIN_DAILY_COST_USD", 10.0)
    daily_cost_owner: float = _float("LIMIT_OWNER_DAILY_COST_USD", 100.0)
    global_daily_budget: float = _float("GLOBAL_DAILY_BUDGET_USD", 50.0)

    cors_origins: tuple[str, ...] = field(
        default_factory=lambda: tuple(
            origin.strip()
            for origin in (os.getenv("CORS_ORIGINS", "*")).split(",")
            if origin.strip()
        )
    )

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def dev_auth_enabled(self) -> bool:
        """Login de desenvolvimento existe apenas fora de produção."""
        return self.auth_mode == "dev" and not self.is_production

    # --- quem é quem (bootstrap dos papéis privilegiados) ------------------
    def email_is_owner(self, email: str | None) -> bool:
        return bool(email) and email.strip().lower() in self.owner_emails

    def uid_is_owner(self, uid: str | None) -> bool:
        return bool(uid) and uid.strip().lower() in self.owner_uids

    def email_is_admin(self, email: str | None) -> bool:
        return bool(email) and email.strip().lower() in self.admin_emails

    def uid_is_admin(self, uid: str | None) -> bool:
        return bool(uid) and uid.strip().lower() in self.admin_uids

    def entitlements_for(self, role: str) -> tuple[int, float]:
        """(mensagens/dia, custo/dia em USD) conforme o papel."""
        return {
            "OWNER": (self.daily_messages_owner, self.daily_cost_owner),
            "ADMIN": (self.daily_messages_admin, self.daily_cost_admin),
        }.get(role, (self.daily_messages_user, self.daily_cost_user))


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    global _settings
    _settings = Settings()
    return _settings
