"""Limites reais de uso — impostos pelo servidor, não pelo aplicativo."""
from __future__ import annotations

from dataclasses import dataclass

from auth.service import Identity
from services.settings import get_settings
from services.store import STORE, UsageRecord, today


class LimitExceeded(Exception):
    """Levantada quando o pedido passa de um limite real (mensagens, custo ou budget)."""

    def __init__(self, message: str, *, scope: str, retry_after_seconds: int = 3600) -> None:
        super().__init__(message)
        self.scope = scope
        self.retry_after_seconds = retry_after_seconds


@dataclass(frozen=True)
class LimitStatus:
    daily_messages_used: int
    daily_messages_limit: int
    daily_cost_used_usd: float
    daily_cost_limit_usd: float
    global_cost_used_usd: float
    global_cost_limit_usd: float
    kill_switch: bool


def kill_switch_enabled() -> bool:
    return STORE.settings_overrides.get("kill_switch", "false").lower() == "true"


def user_limits(user: Identity) -> tuple[int, float]:
    """Limites do usuário (padrão do papel, com ajuste individual se existir)."""
    settings = get_settings()
    messages, cost = settings.entitlements_for(user.role.value)
    record = STORE.get_user(user.uid)
    if record and record.daily_message_limit is not None:
        messages = record.daily_message_limit
    return messages, cost


def status_for(user: Identity) -> LimitStatus:
    settings = get_settings()
    messages_limit, cost_limit = user_limits(user)
    usage: UsageRecord = STORE.usage_for(user.uid)
    global_usage = STORE.global_usage()
    return LimitStatus(
        daily_messages_used=usage.messages,
        daily_messages_limit=messages_limit,
        daily_cost_used_usd=round(usage.cost_usd, 4),
        daily_cost_limit_usd=cost_limit,
        global_cost_used_usd=round(global_usage.cost_usd, 4),
        global_cost_limit_usd=settings.global_daily_budget,
        kill_switch=kill_switch_enabled(),
    )


def enforce_before_request(user: Identity, estimated_cost_usd: float = 0.0) -> None:
    """
    Verificações feitas ANTES de gastar dinheiro no provedor.

    1. Conta bloqueada pelo Modo Deus → 403.
    2. Interruptor geral ligado → ninguém gera, exceto o OWNER (para não travar o dono fora).
    3. Limite diário de mensagens do papel.
    4. Limite diário de custo do usuário.
    5. Teto diário global (todos os usuários somados) — o limite do provedor/pagamento.
    """
    record = STORE.get_user(user.uid)
    if record and record.blocked:
        raise LimitExceeded(
            "Sua conta está bloqueada pelo administrador da NARDEK IA.",
            scope="account_blocked",
            retry_after_seconds=86400,
        )

    if kill_switch_enabled() and user.role.value != "OWNER":
        raise LimitExceeded(
            "A NARDEK IA está em manutenção (interruptor geral do Modo Deus).",
            scope="kill_switch",
        )

    messages_limit, cost_limit = user_limits(user)
    usage = STORE.usage_for(user.uid)
    settings = get_settings()

    if usage.messages >= messages_limit:
        raise LimitExceeded(
            f"Limite diário de {messages_limit} mensagens atingido para o seu perfil. "
            "O contador zera à meia-noite (UTC).",
            scope="daily_messages",
        )

    if usage.cost_usd + estimated_cost_usd > cost_limit:
        raise LimitExceeded(
            f"Limite diário de custo (US$ {cost_limit:.2f}) atingido para o seu perfil.",
            scope="daily_cost",
        )

    global_usage = STORE.global_usage()
    if global_usage.cost_usd + estimated_cost_usd > settings.global_daily_budget:
        raise LimitExceeded(
            "O teto de gasto diário da NARDEK IA foi atingido. "
            "O serviço volta a responder quando o orçamento renovar.",
            scope="global_budget",
            retry_after_seconds=1800,
        )


def register_usage(user: Identity, *, tokens_in: int, tokens_out: int, cost_usd: float) -> UsageRecord:
    usage = STORE.usage_for(user.uid)
    usage.messages += 1
    usage.tokens_in += tokens_in
    usage.tokens_out += tokens_out
    usage.cost_usd = round(usage.cost_usd + cost_usd, 6)
    return usage


def reset_usage(uid: str) -> None:
    STORE.usage.pop((uid, today()), None)
