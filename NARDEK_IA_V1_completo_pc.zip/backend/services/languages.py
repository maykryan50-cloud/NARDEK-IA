"""
Idiomas da NARDEK IA.

Dois conceitos diferentes, como pedido:
  * Idioma da INTERFACE  → escolhido no aplicativo (Android, não passa pelo servidor).
  * Idioma de RESPOSTA   → enviado em cada requisição de chat; o servidor aplica.

O valor especial "auto" significa: "responda no idioma da mensagem do usuário".
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LanguageSpec:
    code: str          # BCP-47, ex.: pt-BR
    label: str         # nome no próprio idioma
    flag: str


SUPPORTED: tuple[LanguageSpec, ...] = (
    LanguageSpec("pt-BR", "Português (Brasil)", "🇧🇷"),
    LanguageSpec("en-US", "English (US)", "🇺🇸"),
    LanguageSpec("es-ES", "Español", "🇪🇸"),
    LanguageSpec("fr-FR", "Français", "🇫🇷"),
    LanguageSpec("de-DE", "Deutsch", "🇩🇪"),
    LanguageSpec("it-IT", "Italiano", "🇮🇹"),
    LanguageSpec("ja-JP", "日本語", "🇯🇵"),
    LanguageSpec("zh-CN", "中文", "🇨🇳"),
)

AUTO = "auto"

#: Vocabulário mínimo para a detecção heurística da V1.
#: Na V3 esta função é substituída por um modelo de detecção de idioma.
_HINTS: dict[str, tuple[str, ...]] = {
    "pt-BR": ("que", "você", "não", "uma", "para", "como", "obrigado", "olá", "oi ", "está", "ção"),
    "en-US": ("the", "you", "and", "what", "how", "thanks", "hello", "please", "is ", "this"),
    "es-ES": ("que", "cómo", "gracias", "hola", "usted", "para", "muy", "está", "porque"),
    "fr-FR": ("vous", "bonjour", "merci", "comment", "pour", "avec", "est-ce"),
    "de-DE": ("und", "nicht", "danke", "hallo", "wie", "ist ", "für"),
}


def detect_language(text: str) -> str:
    """Heurística simples (V1). Suficiente para acertar o idioma das frases usuais."""
    lowered = f" {text.lower()} "
    scores: dict[str, int] = {}
    for code, markers in _HINTS.items():
        scores[code] = sum(1 for marker in markers if marker in lowered)
    best = max(scores, key=lambda code: scores[code])
    return best if scores[best] > 0 else "pt-BR"


def resolve(requested: str | None, message: str) -> str:
    """Define o idioma final da resposta."""
    if not requested or requested.strip().lower() == AUTO:
        return detect_language(message)
    return requested


def instruction_for(code: str) -> str:
    """Instrução colocada no prompt do modelo para fixar o idioma da resposta."""
    label = next((spec.label for spec in SUPPORTED if spec.code == code), code)
    return f"Responda sempre em {label} ({code}), mantendo o mesmo idioma do início ao fim."


def catalog() -> list[dict]:
    return [
        {"code": AUTO, "label": "🌐 Responder no idioma da mensagem", "auto": True},
        *[{"code": s.code, "label": s.label, "flag": s.flag, "auto": False} for s in SUPPORTED],
    ]
