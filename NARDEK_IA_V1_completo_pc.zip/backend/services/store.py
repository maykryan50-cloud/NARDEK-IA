"""
Memória de curto prazo do servidor (V1).

Guarda, por processo:
  * contadores diários de uso (limites reais),
  * registros de usuários vistos (para o painel Modo Deus),
  * log de auditoria das ações administrativas,
  * ajustes de runtime do painel.

Troca por banco de dados (Postgres/SQLite) na V4, sem mudar as rotas.
"""
from __future__ import annotations

import itertools
import threading
import time
from dataclasses import dataclass, field


def today() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


@dataclass
class UserRecord:
    uid: str
    email: str | None
    display_name: str
    role: str
    provider: str
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    blocked: bool = False
    daily_message_limit: int | None = None  # sobrescreve o padrão do papel


@dataclass
class UsageRecord:
    messages: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0


@dataclass
class AuditEntry:
    id: int
    actor_uid: str
    actor_email: str | None
    action: str
    target: str | None
    detail: str
    created_at: float = field(default_factory=time.time)


class Store:
    """Armazenamento em memória, seguro para uso concorrente."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.users: dict[str, UserRecord] = {}
        self.usage: dict[tuple[str, str], UsageRecord] = {}  # (uid, dia) → uso
        self.audit: list[AuditEntry] = []
        self.settings_overrides: dict[str, str] = {}
        self.experiments_used: dict[str, int] = {}
        self._audit_ids = itertools.count(1)

    # --- usuários ---------------------------------------------------------
    def upsert_user(self, *, uid: str, email: str | None, display_name: str, role: str, provider: str) -> UserRecord:
        with self._lock:
            record = self.users.get(uid)
            if record is None:
                record = UserRecord(uid=uid, email=email, display_name=display_name, role=role, provider=provider)
                self.users[uid] = record
            else:
                record.last_seen = time.time()
                record.email = email or record.email
                record.display_name = display_name or record.display_name
                # O papel é sempre reavaliado pelo servidor, mas nunca rebaixado
                # silenciosamente: promover é seguro, rebaixar exige ação do dono.
                if role == "OWNER" or (role == "ADMIN" and record.role == "USER"):
                    record.role = role
            return record

    def get_user(self, uid: str) -> UserRecord | None:
        return self.users.get(uid)

    def list_users(self) -> list[UserRecord]:
        return sorted(self.users.values(), key=lambda u: u.last_seen, reverse=True)

    # --- uso --------------------------------------------------------------
    def usage_for(self, uid: str, day: str | None = None) -> UsageRecord:
        key = (uid, day or today())
        with self._lock:
            return self.usage.setdefault(key, UsageRecord())

    def global_usage(self, day: str | None = None) -> UsageRecord:
        day = day or today()
        total = UsageRecord()
        with self._lock:
            for (uid, day_key), record in self.usage.items():
                if day_key != day:
                    continue
                total.messages += record.messages
                total.tokens_in += record.tokens_in
                total.tokens_out += record.tokens_out
                total.cost_usd += record.cost_usd
        return total

    # --- auditoria --------------------------------------------------------
    def record_audit(self, *, actor_uid: str, actor_email: str | None, action: str,
                     target: str | None = None, detail: str = "") -> AuditEntry:
        with self._lock:
            entry = AuditEntry(
                id=next(self._audit_ids),
                actor_uid=actor_uid,
                actor_email=actor_email,
                action=action,
                target=target,
                detail=detail,
            )
            self.audit.insert(0, entry)
            del self.audit[500:]
            return entry


STORE = Store()
