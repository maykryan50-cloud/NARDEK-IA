"""
Provedores de IA.

O aplicativo NUNCA fala com o provedor: quem fala é este módulo.
A chave de API vive em variável de ambiente no servidor.

  * MockProvider  → responde localmente (V1, sem custo, sem internet).
  * OpenAIProvider → provedor real, ativado quando OPENAI_API_KEY existir.
"""
from __future__ import annotations

from dataclasses import dataclass

from services.settings import get_settings


@dataclass(frozen=True)
class ProviderReply:
    text: str
    tokens_in: int
    tokens_out: int
    provider: str
    degraded: bool = False


class AIProvider:
    name = "base"

    async def complete(
        self,
        *,
        system_prompt: str,
        user_message: str,
        history: list[dict],
        model_name: str,
        temperature: float,
        max_tokens: int,
    ) -> ProviderReply:  # pragma: no cover - interface
        raise NotImplementedError


class MockProvider(AIProvider):
    """
    Provedor de desenvolvimento: monta uma resposta plausível, no idioma pedido,
    e informa os tokens estimados. Serve para o app e o backend conversarem de
    verdade antes de existir conta paga no provedor.
    """

    name = "mock"

    async def complete(
        self,
        *,
        system_prompt: str,
        user_message: str,
        history: list[dict],
        model_name: str,
        temperature: float,
        max_tokens: int,
    ) -> ProviderReply:
        idioma = system_prompt.split("Responda sempre em ")[-1].split(" (")[0] \
            if "Responda sempre em " in system_prompt else "português"

        text = (
            f"[NARDEK IA · {model_name} · provedor de desenvolvimento]\n\n"
            f"Recebi sua mensagem: \"{user_message.strip()}\"\n\n"
            f"Contexto considerado: {len(history)} mensagem(ns) anteriores.\n"
            f"Idioma definido para esta resposta: {idioma}.\n\n"
            "O motor real de IA ainda não está conectado neste servidor: falta "
            "configurar a chave do provedor (variável de ambiente, nunca no APK). "
            "A partir daí, esta mesma rota devolve a resposta do modelo de verdade — "
            "sem mudar nada no aplicativo."
        )
        tokens_in = max(1, len(user_message) // 4) + len(system_prompt) // 4
        tokens_out = len(text) // 4
        return ProviderReply(text=text, tokens_in=tokens_in, tokens_out=tokens_out, provider=self.name)


class OpenAIProvider(AIProvider):
    """Provedor real (compatível com a API OpenAI). Chave somente no servidor."""

    name = "openai"

    def __init__(self, api_key: str, base_url: str, timeout: float) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    async def complete(
        self,
        *,
        system_prompt: str,
        user_message: str,
        history: list[dict],
        model_name: str,
        temperature: float,
        max_tokens: int,
    ) -> ProviderReply:
        import httpx  # import local: só quem usa o provedor real precisa da dependência

        payload = {
            "model": model_name,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system_prompt},
                *history,
                {"role": "user", "content": user_message},
            ],
        }
        headers = {"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/chat/completions", json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        usage = data.get("usage", {}) or {}
        return ProviderReply(
            text=data["choices"][0]["message"]["content"],
            tokens_in=int(usage.get("prompt_tokens", 0)),
            tokens_out=int(usage.get("completion_tokens", 0)),
            provider=self.name,
        )


def get_provider() -> AIProvider:
    """Escolhe o provedor conforme a configuração do servidor."""
    settings = get_settings()
    if settings.ai_provider == "openai" and settings.ai_api_key:
        return OpenAIProvider(settings.ai_api_key, settings.ai_base_url, settings.ai_timeout_seconds)
    return MockProvider()
