"""
NARDEK Lab — área de experimentos.

Fica separada do chat para que recursos experimentais nunca entrem em produção
por acidente: tudo aqui depende de permissão e é registrado na auditoria.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from auth.dependencies import get_current_user, require_permission
from auth.roles import Permission
from auth.service import Identity
from services.store import STORE

router = APIRouter(prefix="/lab", tags=["lab"])

#: Experimentos registrados. `public` = o usuário comum pode ver que existe.
EXPERIMENTS: dict[str, dict] = {
    "prompt-playground": {
        "title": "Playground de prompt",
        "description": "Testa variações do prompt de sistema sem afetar produção.",
        "status": "disponivel",
        "public": True,
    },
    "language-detect": {
        "title": "Detector de idioma",
        "description": "Mostra qual idioma o servidor detectou na mensagem.",
        "status": "disponivel",
        "public": True,
    },
    "model-compare": {
        "title": "Comparador de modelos",
        "description": "Roda a mesma pergunta em modelos diferentes e compara.",
        "status": "em_construcao",
        "public": True,
    },
}


@router.get("/experiments")
async def list_experiments(user: Identity = Depends(get_current_user)) -> dict:
    """Lista o que existe no Lab (usuário comum vê apenas os públicos)."""
    privileged = user.role.value in {"ADMIN", "OWNER"}
    items = [
        {"id": key, **value}
        for key, value in EXPERIMENTS.items()
        if value["public"] or privileged
    ]
    return {"experiments": items, "privileged_view": privileged}


@router.post("/experiments/{experiment_id}/run")
async def run_experiment(
    experiment_id: str,
    payload: dict | None = None,
    user: Identity = Depends(require_permission(Permission.ADMIN_TOOLS)),
) -> dict:
    """Executa um experimento. Restrito à equipe e registrado na auditoria."""
    spec = EXPERIMENTS.get(experiment_id)
    if spec is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Experimento não encontrado.")
    if spec["status"] != "disponivel":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"O experimento '{spec['title']}' ainda está em construção.",
        )

    argument = (payload or {}).get("input", "")
    STORE.experiments_used[experiment_id] = STORE.experiments_used.get(experiment_id, 0) + 1
    STORE.record_audit(
        actor_uid=user.uid,
        actor_email=user.email,
        action=f"lab.run.{experiment_id}",
        detail=f"execuções={STORE.experiments_used[experiment_id]}",
    )

    if experiment_id == "language-detect":
        from services.languages import detect_language

        return {"experiment": experiment_id, "detected": detect_language(str(argument)), "input": argument}

    return {
        "experiment": experiment_id,
        "note": "Experimento registrado. A ligação com o provedor real entra na V2.",
    }
