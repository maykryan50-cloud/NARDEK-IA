"""Contratos do painel administrativo (Modo Deus)."""
from __future__ import annotations

from pydantic import BaseModel, Field

from auth.roles import Role


class UserPatch(BaseModel):
    """Alterações que o proprietário pode aplicar a um usuário."""

    role: Role | None = Field(None, description="Novo papel: USER, ADMIN ou OWNER")
    blocked: bool | None = Field(None, description="Bloquear/desbloquear o acesso")
    daily_message_limit: int | None = Field(
        None, ge=1, le=1_000_000, description="Limite diário individual (sobrescreve o do papel)"
    )


class SettingsPatch(BaseModel):
    """Ajustes de runtime aplicados pelo proprietário (valem para o servidor inteiro)."""

    kill_switch: bool | None = None
    ai_system_prompt: str | None = Field(None, max_length=4000)
    ai_temperature: float | None = Field(None, ge=0.0, le=2.0)
    ai_max_tokens: int | None = Field(None, ge=64, le=16384)
    ai_style: str | None = Field(None, pattern="^(padrao|direto)$")
    global_daily_budget_usd: float | None = Field(None, gt=0, le=10_000)


class ToolRunRequest(BaseModel):
    argument: str | None = None


class UserView(BaseModel):
    uid: str
    email: str | None
    display_name: str
    role: Role
    provider: str
    blocked: bool
    daily_message_limit: int | None
    messages_today: int
    cost_today_usd: float
