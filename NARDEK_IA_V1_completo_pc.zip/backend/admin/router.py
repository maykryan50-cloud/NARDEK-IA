"""
Painel administrativo da NARDEK IA — o "Modo Deus".

REGRA CENTRAL: cada rota daqui exige uma permissão verificada pelo SERVIDOR
(auth/dependencies.py + auth/roles.py). O aplicativo pode esconder a tela,
mas mesmo que alguém chame a API direto com o token de um usuário comum,
a resposta é 403. Nenhum papel é aceito por declaração do cliente.

  GET    /admin/overview              → visão geral (ADMIN ou OWNER)
  GET    /admin/users                 → lista de usuários (ADMIN ou OWNER)
  PATCH  /admin/users/{uid}           → mudar papel/bloquear/limite (SOMENTE OWNER)
  GET    /admin/models                → catálogo completo (ADMIN ou OWNER)
  GET    /admin/settings              → configurações efetivas (ADMIN ou OWNER)
  PATCH  /admin/settings              → alterar configurações (SOMENTE OWNER)
  GET    /admin/audit                 → log de auditoria (ADMIN ou OWNER)
  POST   /admin/tools/{tool}          → ferramentas de teste (ADMIN ou OWNER)
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from admin.schemas import SettingsPatch, ToolRunRequest, UserPatch, UserView
from auth.dependencies import require_permission, require_role
from auth.roles import Permission, Role, permissions_for
from auth.service import Identity
from models.catalog import CATALOG
from services import limits
from services.settings import get_settings
from services.store import STORE

router = APIRouter(prefix="/admin", tags=["admin (Modo Deus)"])

#: Ferramentas de desenvolvimento disponíveis para a equipe.
TOOLS: dict[str, str] = {
    "ping": "Verifica se o servidor está respondendo.",
    "echo-models": "Devolve o catálogo exatamente como o servidor enxerga.",
    "reset-usage": "Zera o contador diário de mensagens (somente OWNER).",
}


def _user_view(uid: str) -> UserView:
    record = STORE.get_user(uid)
    usage = STORE.usage_for(uid)
    return UserView(
        uid=uid,
        email=record.email if record else None,
        display_name=record.display_name if record else "—",
        role=Role(record.role) if record else Role.USER,
        provider=record.provider if record else "—",
        blocked=record.blocked if record else False,
        daily_message_limit=record.daily_message_limit if record else None,
        messages_today=usage.messages,
        cost_today_usd=round(usage.cost_usd, 4),
    )


@router.get("/overview")
async def overview(user: Identity = Depends(require_permission(Permission.ADMIN_PANEL))) -> dict:
    """Visão geral do sistema usada no topo do painel."""
    settings = get_settings()
    global_usage = STORE.global_usage()
    return {
        "server": {
            "env": settings.env,
            "auth_mode": settings.auth_mode,
            "ai_provider": settings.ai_provider,
            "ai_key_configured": bool(settings.ai_api_key),  # apenas SIM/NÃO, nunca a chave
        },
        "people": {
            "known_users": len(STORE.users),
            "owners": sum(1 for u in STORE.users.values() if u.role == "OWNER"),
            "admins": sum(1 for u in STORE.users.values() if u.role == "ADMIN"),
            "blocked": sum(1 for u in STORE.users.values() if u.blocked),
        },
        "today": {
            "messages": global_usage.messages,
            "tokens_in": global_usage.tokens_in,
            "tokens_out": global_usage.tokens_out,
            "cost_usd": round(global_usage.cost_usd, 4),
            "budget_usd": settings.global_daily_budget,
        },
        "flags": {"kill_switch": limits.kill_switch_enabled()},
        "you": {"uid": user.uid, "role": user.role.value, "permissions": permissions_for(user.role)},
    }


@router.get("/users", response_model=list[UserView])
async def list_users(
    query: str | None = None,
    user: Identity = Depends(require_permission(Permission.ADMIN_USERS_VIEW)),
) -> list[UserView]:
    """Usuários conhecidos pelo servidor (mais recentes primeiro)."""
    records = STORE.list_users()
    if query:
        needle = query.strip().lower()
        records = [
            r for r in records
            if needle in (r.email or "").lower() or needle in r.display_name.lower() or needle in r.uid.lower()
        ]
    return [_user_view(record.uid) for record in records]


@router.patch("/users/{uid}", response_model=UserView)
async def update_user(
    uid: str,
    patch: UserPatch,
    user: Identity = Depends(require_permission(Permission.GOD_USERS_MANAGE)),
) -> UserView:
    """Altera papel, bloqueio ou limite individual. Exclusivo do proprietário."""
    record = STORE.get_user(uid)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado neste servidor.")
    if uid == user.uid and patch.blocked:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Você não pode bloquear a própria conta de proprietário.",
        )
    if uid == user.uid and patch.role and patch.role != Role.OWNER:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Você não pode rebaixar o próprio papel de OWNER.",
        )
    if record.role == "OWNER" and record.uid != user.uid:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Outra conta OWNER só pode ser alterada por ela mesma.",
        )

    changes: list[str] = []
    if patch.role is not None and patch.role.value != record.role:
        record.role = patch.role.value
        changes.append(f"papel→{patch.role.value}")
    if patch.blocked is not None and patch.blocked != record.blocked:
        record.blocked = patch.blocked
        changes.append(f"bloqueado→{patch.blocked}")
    if patch.daily_message_limit is not None:
        record.daily_message_limit = patch.daily_message_limit
        changes.append(f"limite→{patch.daily_message_limit}")

    STORE.record_audit(
        actor_uid=user.uid,
        actor_email=user.email,
        action="god.user.update",
        target=uid,
        detail=", ".join(changes) or "nenhuma alteração",
    )
    return _user_view(uid)


@router.get("/models")
async def admin_models(user: Identity = Depends(require_permission(Permission.ADMIN_MODELS_VIEW))) -> dict:
    """Catálogo completo, incluindo modelos desligados e restritos."""
    return {
        "models": [
            {
                "id": spec.id,
                "name": spec.name,
                "description": spec.description,
                "min_role": spec.min_role.value,
                "enabled": spec.enabled,
                "supports_vision": spec.supports_vision,
                "supports_web": spec.supports_web,
                "context_tokens": spec.context_tokens,
                "cost_per_1k_in": spec.cost_per_1k_in,
                "cost_per_1k_out": spec.cost_per_1k_out,
            }
            for spec in CATALOG
        ]
    }


def _effective_settings() -> dict:
    settings = get_settings()
    overrides = STORE.settings_overrides
    return {
        "ai": {
            "provider": settings.ai_provider,
            "key_configured": bool(settings.ai_api_key),
            "system_prompt_custom": overrides.get("ai.system_prompt"),
            "temperature": float(overrides.get("ai.temperature", "0.7")),
            "max_tokens": int(overrides.get("ai.max_tokens", "1024")),
            "style": overrides.get("ai.style", "padrao"),
        },
        "limits": {
            "daily_messages_user": settings.daily_messages_user,
            "daily_messages_admin": settings.daily_messages_admin,
            "daily_messages_owner": settings.daily_messages_owner,
            "global_daily_budget_usd": settings.global_daily_budget,
        },
        "flags": {"kill_switch": limits.kill_switch_enabled()},
    }


@router.get("/settings")
async def read_settings(user: Identity = Depends(require_permission(Permission.ADMIN_PANEL))) -> dict:
    """Configurações efetivas do servidor (segredos aparecem apenas como SIM/NÃO)."""
    return _effective_settings()


@router.patch("/settings")
async def patch_settings(
    patch: SettingsPatch,
    user: Identity = Depends(require_permission(Permission.GOD_SETTINGS_MANAGE)),
) -> dict:
    """Altera configurações em tempo real. Exclusivo do proprietário."""
    overrides = STORE.settings_overrides
    changed: list[str] = []

    if patch.kill_switch is not None:
        overrides["kill_switch"] = "true" if patch.kill_switch else "false"
        changed.append(f"kill_switch={patch.kill_switch}")
    if patch.ai_system_prompt is not None:
        overrides["ai.system_prompt"] = patch.ai_system_prompt
        changed.append("ai.system_prompt")
    if patch.ai_temperature is not None:
        overrides["ai.temperature"] = str(patch.ai_temperature)
        changed.append(f"ai.temperature={patch.ai_temperature}")
    if patch.ai_max_tokens is not None:
        overrides["ai.max_tokens"] = str(patch.ai_max_tokens)
        changed.append(f"ai.max_tokens={patch.ai_max_tokens}")
    if patch.ai_style is not None:
        overrides["ai.style"] = patch.ai_style
        changed.append(f"ai.style={patch.ai_style}")
    if patch.global_daily_budget_usd is not None:
        overrides["global_daily_budget_usd"] = str(patch.global_daily_budget_usd)
        changed.append(f"budget={patch.global_daily_budget_usd}")

    STORE.record_audit(
        actor_uid=user.uid,
        actor_email=user.email,
        action="god.settings.update",
        detail=", ".join(changed) or "nenhuma alteração",
    )
    return _effective_settings()


@router.get("/audit")
async def read_audit(
    limit: int = 100,
    user: Identity = Depends(require_permission(Permission.ADMIN_AUDIT_VIEW)),
) -> dict:
    """Últimas ações administrativas registradas pelo servidor."""
    entries = STORE.audit[: max(1, min(limit, 500))]
    return {
        "entries": [
            {
                "id": entry.id,
                "actor": entry.actor_email or entry.actor_uid,
                "action": entry.action,
                "target": entry.target,
                "detail": entry.detail,
                "created_at": entry.created_at,
            }
            for entry in entries
        ]
    }


@router.post("/tools/{tool}")
async def run_tool(
    tool: str,
    payload: ToolRunRequest | None = None,
    user: Identity = Depends(require_permission(Permission.ADMIN_TOOLS)),
) -> dict:
    """Ferramentas de desenvolvimento/teste da equipe."""
    if tool not in TOOLS:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Ferramenta '{tool}' não existe.")
    if tool == "reset-usage" and user.role != Role.OWNER:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Apenas o proprietário pode zerar contadores de uso.",
        )

    STORE.record_audit(
        actor_uid=user.uid,
        actor_email=user.email,
        action=f"god.tool.{tool}",
        target=(payload.argument if payload else None),
        detail="executada",
    )

    if tool == "ping":
        return {"tool": tool, "result": "pong", "actor": user.role.value}
    if tool == "echo-models":
        return {"tool": tool, "result": [spec.id for spec in CATALOG]}
    uid = (payload.argument if payload and payload.argument else user.uid)
    limits.reset_usage(uid)
    return {"tool": tool, "result": f"contadores zerados para {uid}"}
