# NARDEK IA — Backend (Python + FastAPI)

Servidor da NARDEK IA. É aqui que vivem as **chaves de API**, os **limites** e as
**permissões** (USER / ADMIN / OWNER). O aplicativo Android nunca fala com o
provedor de IA: ele fala com este servidor.

---

## Estrutura

```
backend/
├── main.py                 ponto de entrada (FastAPI + CORS)
├── requirements.txt        dependências
├── env.example             modelo de configuração (.env)
├── api/
│   ├── router.py           agrega todas as rotas em /api/v1
│   ├── health.py           GET /api/v1/health
│   └── me.py               GET /api/v1/me  → uid, email, papel, permissões, limites
├── auth/
│   ├── roles.py            papéis (USER, ADMIN, OWNER) e mapa de permissões
│   ├── service.py          validação de token (dev por HMAC; Firebase na V3)
│   ├── dependencies.py     get_current_user / require_role / require_permission
│   └── router.py           POST /api/v1/auth/dev-login, GET /auth/providers
├── chat/
│   ├── schemas.py          contratos do chat (mensagem, modelo, idioma)
│   ├── service.py          regras: modelo → idioma → limites → provedor
│   └── router.py           POST /api/v1/chat, GET /chat/models, GET /chat/languages
├── admin/                  MODO DEUS (validado no servidor)
│   ├── schemas.py
│   └── router.py           /api/v1/admin/overview, users, models, settings, audit, tools
├── lab/                    NARDEK Lab (experimentos, restrito à equipe)
├── memory/                 memória por usuário (V1 em memória; V10 definitivo)
├── models/catalog.py       catálogo de modelos (NARDEK, NARDEK Pro, NARDEK Owner…)
└── services/
    ├── settings.py         configuração por variável de ambiente
    ├── store.py            estado em memória (uso, usuários, auditoria)
    ├── limits.py           limites diários, orçamento global, interruptor geral
    ├── languages.py        8 idiomas + detecção automática da mensagem
    └── ai_provider.py      MockProvider (agora) e OpenAIProvider (quando houver chave)
```

---

## Como rodar

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate   # opcional
pip install -r requirements.txt

cp env.example .env        # edite o .env (no Windows: copy env.example .env)
python main.py             # sobe em http://0.0.0.0:8000
```

Documentação automática das rotas: `http://localhost:8000/docs` (desligada em produção).

### Testar de verdade

```bash
python -m pytest tests/ -q
```

Os 17 testes cobrem: saúde da API, `/me` sem token (401), papéis definidos pelo
servidor, chat com modelo e idioma, limite diário (429), usuário comum bloqueado
no painel (403), ADMIN que não muda papéis, OWNER que promove com auditoria,
proteção contra o dono se bloquear, interruptor geral e memória por usuário.

---

## Modo Deus: como a segurança funciona

1. **Papéis vêm do servidor.** `OWNER_EMAILS` / `OWNER_UIDS` / `ADMIN_EMAILS` /
   `ADMIN_UIDS` no `.env`. Nada que o aplicativo envie é considerado.
2. **Cada rota administrativa exige permissão** (`auth/dependencies.py`). Chamar
   a API com token de usuário comum devolve `403`, mesmo que a tela tenha sido
   forçada no APK.
3. **Toda ação administrativa vai para a auditoria** (`/api/v1/admin/audit`),
   com autor, alvo e o que mudou.
4. **Limites são do servidor**: mensagens/dia e custo/dia por papel, mais um
   teto global diário. O proprietário tem limites altos — mas não infinitos,
   porque o custo real é da API do provedor.
5. **O interruptor geral** (kill switch) pausa a geração para todos, menos para
   o OWNER — para o dono não se trancar fora do próprio sistema.

---

## Próximos passos do backend

- **V2**: plugar o provedor real (`AI_PROVIDER=openai` + `OPENAI_API_KEY`) e
  streaming SSE no `/api/v1/chat`.
- **V3**: validar o ID token do Firebase (Google Sign-In) em `auth/service.py`.
- **V4**: trocar `services/store.py` por banco de dados (conversas e uso).
- **V10**: memória persistente com controles de privacidade.
