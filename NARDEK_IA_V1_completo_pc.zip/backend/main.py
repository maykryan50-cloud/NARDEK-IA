"""
============================================================
 NARDEK IA — API (FastAPI)
============================================================
Ponto de entrada do backend.

Arquitetura (pastas pequenas e modulares):

  api/       → rotas agregadas: /health, /api/v1/me
  auth/      → identidade, tokens, papéis (USER, ADMIN, OWNER)
  chat/      → conversa com a IA (mockado por enquanto)
  lab/       → NARDEK Lab (experimentos, área protegida)
  memory/    → memória do usuário (V1: em memória, troca por banco depois)
  admin/     → Modo Deus (painel administrativo, validado NO SERVIDOR)
  models/    → catálogo de modelos (NARDEK, NARDEK Pro, ...)
  services/  → provedores de IA, configuração, segurança, idiomas, limites

Regras críticas:
  * Nenhuma chave de API sai daqui para o aplicativo.
  * Nenhuma decisão de permissão é tomada no app: só o servidor decide.
============================================================
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.router import api_router
from services.settings import get_settings

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version=settings.api_version,
    description="Backend da NARDEK IA. Chaves de IA e permissões vivem apenas aqui.",
    docs_url="/docs" if not settings.is_production else None,
    redoc_url=None,
)

# --- CORS: o aplicativo Android (e o painel web futuro) consomem esta API ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=False,  # usamos token Bearer, não cookie
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Nardek-Client"],
)

app.include_router(api_router)


if __name__ == "__main__":  # execução local: python main.py
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",  # aceita conexões do emulador/celular na rede
        port=8000,
        reload=not settings.is_production,
    )
