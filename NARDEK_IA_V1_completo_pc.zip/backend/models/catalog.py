"""
Catálogo de modelos da NARDEK IA.

O aplicativo recebe apenas a lista permitida para o papel do usuário.
Provedor real, custo e chaves ficam no servidor.
"""
from __future__ import annotations

from dataclasses import dataclass

from auth.roles import Role, at_least


@dataclass(frozen=True)
class ModelSpec:
    id: str
    name: str
    description: str
    min_role: Role
    enabled: bool = True
    supports_vision: bool = False
    supports_web: bool = False
    context_tokens: int = 8192
    cost_per_1k_in: float = 0.0
    cost_per_1k_out: float = 0.0


#: Catálogo oficial da V1 (o provedor real é plugado em services/ai_provider.py)
CATALOG: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="nardek",
        name="NARDEK",
        description="Modelo padrão: rápido e equilibrado para o dia a dia.",
        min_role=Role.USER,
        cost_per_1k_in=0.00015,
        cost_per_1k_out=0.0006,
    ),
    ModelSpec(
        id="nardek-pro",
        name="NARDEK Pro",
        description="Raciocínio mais profundo para tarefas complexas. Restrito à equipe.",
        min_role=Role.ADMIN,
        context_tokens=32768,
        cost_per_1k_in=0.0025,
        cost_per_1k_out=0.01,
    ),
    ModelSpec(
        id="nardek-owner",
        name="NARDEK Owner",
        description="Modelo máximo, disponível apenas para o proprietário (Modo Deus).",
        min_role=Role.OWNER,
        context_tokens=128000,
        cost_per_1k_in=0.005,
        cost_per_1k_out=0.015,
    ),
    ModelSpec(
        id="nardek-vision",
        name="NARDEK Vision",
        description="Leitura de imagens. Chega na V6 — ainda desligado.",
        min_role=Role.USER,
        enabled=False,
        supports_vision=True,
    ),
)


def available_for(role: Role) -> list[ModelSpec]:
    """Modelos que o papel pode usar agora."""
    return [m for m in CATALOG if m.enabled and at_least(role, m.min_role)]


def find(model_id: str) -> ModelSpec | None:
    return next((m for m in CATALOG if m.id == model_id), None)
