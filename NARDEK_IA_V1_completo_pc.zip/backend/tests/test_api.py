"""
Testes do backend NARDEK IA.

Cobrem, principalmente, a REGRA DE SEGURANÇA do Modo Deus:
  * sem token → 401
  * usuário comum → 403 em tudo que é administrativo
  * ADMIN entra no painel, mas NÃO muda papéis
  * OWNER entra e muda
  * limites e interruptor geral realmente barram o chat
"""
from __future__ import annotations

import os

# A configuração precisa existir ANTES de importar o app.
os.environ.update(
    {
        "APP_ENV": "development",
        "AUTH_MODE": "dev",
        "SECRET_KEY": "segredo-de-teste",
        "AI_PROVIDER": "mock",
        "OWNER_EMAILS": "dono@nardek.ai",
        "ADMIN_EMAILS": "equipe@nardek.ai",
        "LIMIT_USER_DAILY_MESSAGES": "3",
        "LIMIT_OWNER_DAILY_MESSAGES": "100",
        "GLOBAL_DAILY_BUDGET_USD": "5",
    }
)

import pytest
from fastapi.testclient import TestClient

from main import app
from services.store import STORE

client = TestClient(app)


def login(email: str) -> dict:
    response = client.post("/api/v1/auth/dev-login", json={"email": email, "display_name": email.split("@")[0]})
    assert response.status_code == 200, response.text
    return response.json()


def auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(autouse=True)
def clean_state() -> None:
    STORE.users.clear()
    STORE.usage.clear()
    STORE.audit.clear()
    STORE.settings_overrides.clear()
    STORE.experiments_used.clear()


def test_health_publico():
    assert client.get("/api/v1/health").json()["status"] == "ok"


def test_me_sem_token_e_401():
    assert client.get("/api/v1/me").status_code == 401


def test_dev_login_define_papeis():
    assert login("alguem@gmail.com")["role"] == "USER"
    assert login("equipe@nardek.ai")["role"] == "ADMIN"
    assert login("dono@nardek.ai")["role"] == "OWNER"


def test_me_do_usuario_comum():
    token = login("alguem@gmail.com")["access_token"]
    body = client.get("/api/v1/me", headers=auth(token)).json()
    assert body["role"] == "USER"
    assert body["god_mode"] is False
    assert "god.settings.manage" not in body["permissions"]
    assert body["limits"]["daily_messages_limit"] == 3


def test_me_do_dono_tem_god_mode():
    token = login("dono@nardek.ai")["access_token"]
    body = client.get("/api/v1/me", headers=auth(token)).json()
    assert body["role"] == "OWNER"
    assert body["god_mode"] is True
    assert "god.users.manage" in body["permissions"]


def test_chat_funciona_e_conta_mensagens():
    token = login("alguem@gmail.com")["access_token"]
    payload = {"message": "Olá NARDEK, tudo bem?", "model": "nardek", "response_language": "auto"}
    body = client.post("/api/v1/chat", json=payload, headers=auth(token)).json()
    assert body["language"] == "pt-BR"          # detecção automática
    assert body["limits"]["daily_messages_used"] == 1
    assert "Recebi sua mensagem" in body["reply"]


def test_chat_respeita_idioma_fixo():
    token = login("alguem@gmail.com")["access_token"]
    payload = {"message": "hello", "model": "nardek", "response_language": "en-US"}
    body = client.post("/api/v1/chat", json=payload, headers=auth(token)).json()
    assert body["language"] == "en-US"
    assert body["language_auto"] is False


def test_chat_bloqueia_modelo_restrito_para_usuario_comum():
    token = login("alguem@gmail.com")["access_token"]
    payload = {"message": "oi", "model": "nardek-owner"}
    assert client.post("/api/v1/chat", json=payload, headers=auth(token)).status_code == 403


def test_chat_limite_diario_real():
    token = login("alguem@gmail.com")["access_token"]
    for _ in range(3):  # LIMIT_USER_DAILY_MESSAGES=3
        assert client.post("/api/v1/chat", json={"message": "oi"}, headers=auth(token)).status_code == 200
    blocked = client.post("/api/v1/chat", json={"message": "oi"}, headers=auth(token))
    assert blocked.status_code == 429
    assert blocked.headers["X-Nardek-Limit"] == "daily_messages"


def test_admin_nao_entra_em_gestao_de_usuarios():
    admin = login("equipe@nardek.ai")["access_token"]
    owner_token = login("dono@nardek.ai")["access_token"]
    owner_uid = client.get("/api/v1/me", headers=auth(owner_token)).json()["uid"]

    # ADMIN vê a lista...
    assert client.get("/api/v1/admin/users", headers=auth(admin)).status_code == 200
    # ...mas não altera papéis (só OWNER pode)
    response = client.patch(f"/api/v1/admin/users/{owner_uid}", json={"role": "ADMIN"}, headers=auth(admin))
    assert response.status_code == 403


def test_usuario_comum_nao_acessa_admin():
    token = login("alguem@gmail.com")["access_token"]
    for route in ("/api/v1/admin/overview", "/api/v1/admin/users", "/api/v1/admin/audit", "/api/v1/admin/settings"):
        assert client.get(route, headers=auth(token)).status_code == 403


def test_owner_promove_usuario_e_registra_auditoria():
    owner = login("dono@nardek.ai")["access_token"]
    target = login("alguem@gmail.com")["access_token"]
    target_uid = client.get("/api/v1/me", headers=auth(target)).json()["uid"]

    response = client.patch(
        f"/api/v1/admin/users/{target_uid}",
        json={"role": "ADMIN", "daily_message_limit": 99},
        headers=auth(owner),
    )
    assert response.status_code == 200
    assert response.json()["role"] == "ADMIN"
    assert response.json()["daily_message_limit"] == 99

    audit = client.get("/api/v1/admin/audit", headers=auth(owner)).json()["entries"]
    assert audit[0]["action"] == "god.user.update"
    assert "papel→ADMIN" in audit[0]["detail"]


def test_owner_nao_consegue_se_bloquear():
    owner = login("dono@nardek.ai")["access_token"]
    uid = client.get("/api/v1/me", headers=auth(owner)).json()["uid"]
    response = client.patch(f"/api/v1/admin/users/{uid}", json={"blocked": True}, headers=auth(owner))
    assert response.status_code == 400


def test_kill_switch_para_todos_menos_o_dono():
    owner = login("dono@nardek.ai")["access_token"]
    user_token = login("alguem@gmail.com")["access_token"]

    assert client.patch("/api/v1/admin/settings", json={"kill_switch": True}, headers=auth(owner)).status_code == 200
    blocked = client.post("/api/v1/chat", json={"message": "oi"}, headers=auth(user_token))
    assert blocked.status_code == 429
    assert blocked.headers["X-Nardek-Limit"] == "kill_switch"
    # o dono continua trabalhando (não se tranca para fora)
    assert client.post("/api/v1/chat", json={"message": "oi"}, headers=auth(owner)).status_code == 200

    # ADMIN também não desliga o interruptor
    admin = login("equipe@nardek.ai")["access_token"]
    assert client.patch("/api/v1/admin/settings", json={"kill_switch": False}, headers=auth(admin)).status_code == 403


def test_usuario_comum_nao_usuario_lab():
    token = login("alguem@gmail.com")["access_token"]
    assert client.post("/api/v1/lab/experiments/language-detect/run", json={"input": "hola amigo"}, headers=auth(token)).status_code == 403
    lab = client.get("/api/v1/lab/experiments", headers=auth(token)).json()
    assert lab["privileged_view"] is False
    assert any(item["id"] == "language-detect" for item in lab["experiments"])


def test_memoria_e_por_usuario():
    token = login("alguem@gmail.com")["access_token"]
    assert client.put("/api/v1/memory", json={"content": "prefere respostas curtas"}, headers=auth(token)).status_code == 200
    assert client.get("/api/v1/memory", headers=auth(token)).json()["count"] == 1

    outro = login("outro@gmail.com")["access_token"]
    assert client.get("/api/v1/memory", headers=auth(outro)).json()["count"] == 0


def test_system_info_nao_vaza_segredo():
    body = client.get("/api/v1/system/info").json()
    assert "ai_api_key" not in body
    assert "secret_key" not in body
