"""Agregador de rotas: tudo o que o aplicativo pode chamar está aqui."""
from __future__ import annotations

from fastapi import APIRouter

from admin.router import router as admin_router
from api.health import router as health_router
from api.me import router as me_router
from auth.router import router as auth_router
from chat.router import router as chat_router
from lab.router import router as lab_router
from memory.router import router as memory_router

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(health_router)
api_router.include_router(auth_router)
api_router.include_router(me_router)
api_router.include_router(chat_router)
api_router.include_router(lab_router)
api_router.include_router(memory_router)
api_router.include_router(admin_router)
