"""
/api/v1/me — identidade do usuário autenticado.

É a única fonte de informação sobre papel e permissões para o aplicativo.
O app usa isso para MOSTRAR ou ESCONDER telas; nunca para autorizar: cada rota
protegida revalida no servidor.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from auth.dependencies import get_current_user
from auth.roles import Role, permissions_for
from auth.service import Identity
from services import limits
from services.settings import get_settings

router = APIRouter(tags=["identity"])


class LimitsView(BaseModel):
    daily_messages_used: int
    daily_messages_limit: int
    daily_cost_used_usd: float
    daily_cost_limit_usd: float
    global_cost_used_usd: float
    global_cost_limit_usd: float


class MeResponse(BaseModel):
    uid: str
    email: str | None
    display_name: str
    role: Role
    permissions: list[str]
    god_mode: bool          # apenas sinaliza à interface; o servidor continua validando tudo
    provider: str
    blocked: bool
    limits: LimitsView


@router.get("/me", response_model=MeResponse)
async def me(user: Identity = Depends(get_current_user)) -> MeResponse:
    status = limits.status_for(user)
    record = limits.STORE.get_user(user.uid)
    return MeResponse(
        uid=user.uid,
        email=user.email,
        display_name=user.display_name,
        role=user.role,
        permissions=permissions_for(user.role),
        god_mode=user.role in {Role.ADMIN, Role.OWNER},
        provider=user.provider,
        blocked=bool(record and record.blocked),
        limits=LimitsView(
            daily_messages_used=status.daily_messages_used,
            daily_messages_limit=status.daily_messages_limit,
            daily_cost_used_usd=status.daily_cost_used_usd,
            daily_cost_limit_usd=status.daily_cost_limit_usd,
            global_cost_used_usd=status.global_cost_used_usd,
            global_cost_limit_usd=status.global_cost_limit_usd,
        ),
    )


@router.get("/system/info")
async def system_info() -> dict:
    """Informações públicas do servidor (sem autenticação e sem segredos)."""
    settings = get_settings()
    return {
        "app": settings.app_name,
        "api_version": settings.api_version,
        "environment": settings.env,
        "ai_provider": settings.ai_provider,
        "ai_key_configured": bool(settings.ai_api_key),
        "firebase_project_id": settings.firebase_project_id,
        "dev_login_available": settings.dev_auth_enabled,
    }
