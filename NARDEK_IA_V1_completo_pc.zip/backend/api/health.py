"""Rotas de saúde do servidor."""
from __future__ import annotations

import time

from fastapi import APIRouter

from services.settings import get_settings

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> dict:
    """Verificação rápida usada pelo aplicativo e por monitoramento externo."""
    settings = get_settings()
    return {
        "status": "ok",
        "service": settings.app_name,
        "api_version": settings.api_version,
        "environment": settings.env,
        "ai_provider": settings.ai_provider,
        "time": int(time.time()),
    }
