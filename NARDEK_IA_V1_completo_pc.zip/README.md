# NARDEK IA

Aplicativo de inteligência artificial próprio.

**Android:** Kotlin + Jetpack Compose · **Backend:** Python + FastAPI · **Auth:** Firebase (V3)

- Package: `com.nexia.app` · minSdk 26 · targetSdk/compileSdk 35
- Repositório: `maykryan50-cloud/NARDEK-IA` (branch `main`)
- Projeto Firebase: `nardek-ia`

---

## Estado atual: V1 (esqueleto modular completo)

O que **existe de verdade** neste repositório:

| Parte | Situação |
|---|---|
| Estrutura modular Android (40 arquivos Kotlin) | ✅ criada |
| Estrutura modular do backend (31 arquivos Python) | ✅ criada |
| Backend rodando com testes automatizados | ✅ 17/17 passando |
| Verificação estática do esqueleto | ✅ `scripts/verificar_esqueleto.py` |
| Ícones do app gerados a partir da logomarca | ✅ mipmaps + símbolo N |
| Strings (pt-BR, en, es) | ✅ 135 chaves |
| **Compilação do APK** | ⏳ **ainda não executada** (próximo passo) |
| Login Google / SHA-1 (V3) | ⏳ depende do APK assinado |

> Regra combinada: nada é dado como pronto sem ter sido verificado. O APK ainda
> **não** foi compilado — o esqueleto foi validado por análise estática e o
> backend por testes reais.

---

## Estrutura do projeto

```
NARDEK_IA/
├── settings.gradle.kts · build.gradle.kts · gradle.properties · gradlew
├── scripts/verificar_esqueleto.py        checagem estática sem compilar
│
├── app/src/main/java/com/nexia/app/
│   ├── MainActivity.kt                   única Activity (Compose)
│   ├── ui/
│   │   ├── NardekRoot.kt                 tema + idioma + menu lateral + navegação
│   │   ├── theme/                        Color.kt · Type.kt · Theme.kt (claro/escuro)
│   │   ├── components/                   marca, bolhas, barra de escrita, menu, topo, locale
│   │   ├── screens/                      Login, Chat, Histórico, Perfil, Configurações, Sobre, Modo Deus, Lab
│   │   └── navigation/                   rotas
│   ├── domain/model/                     ChatMessage, Conversation, Identity, Role, AiModel, idiomas, tema
│   ├── data/
│   │   ├── AppContainer.kt               montagem das dependências
│   │   ├── local/NardekPreferences.kt    preferências do aparelho
│   │   ├── remote/NardekBackend.kt       cliente HTTP do backend
│   │   └── repository/ChatRepository.kt  contrato + versão online e local
│   ├── auth/                             sessão e identidade (papel vem do servidor)
│   ├── chat/                             estado e regras da conversa
│   ├── settings/                         tema, idiomas, preferências
│   ├── lab/                              NARDEK Lab
│   ├── memory/                           memória por usuário
│   └── admin/                            painel Modo Deus (chama o backend)
│
├── app/src/main/res/
│   ├── values/ values-en/ values-es/     strings + cores + tema + ícone
│   ├── drawable-nodpi/nardek_n_badge.png símbolo N (da logomarca) usado no chat
│   └── mipmap-*/                         ícones do launcher (todas as densidades)
│
└── backend/                              ver backend/README.md
    ├── main.py · api/ · auth/ · chat/ · admin/ · lab/ · memory/ · models/ · services/ · tests/
```

---

## Memória: build seguro em VM de 2 GB

`gradle.properties` já vem configurado para **não** ser morto pelo OOM Killer:

```properties
org.gradle.jvmargs=-Xmx512m -XX:MaxMetaspaceSize=192m -Dfile.encoding=UTF-8
kotlin.daemon.jvmargs=-Xmx384m
org.gradle.parallel=false
org.gradle.workers.max=1
```

Se em algum momento o build reclamar de memória, o ajuste é pontual:

| Sintoma | Ajuste |
|---|---|
| `Java heap space` | `org.gradle.jvmargs=-Xmx768m -XX:MaxMetaspaceSize=256m` |
| Build muito lento | manter; **não** ativar `org.gradle.parallel` |
| Máquina de 4 GB+ | `-Xmx1536m -XX:MaxMetaspaceSize=512m` |

Para economizar memória, compilar **uma tarefa por vez** e nunca em paralelo
com outra coisa pesada:

```bash
./gradlew :app:assembleDebug --no-daemon --console=plain
```

---

## Backend em 3 comandos

```bash
cd backend
pip install -r requirements.txt
cp env.example .env        # e edite OWNER_EMAILS com o seu e-mail
python main.py             # http://0.0.0.0:8000
```

No arquivo `.env`, `OWNER_EMAILS` é quem recebe o papel **OWNER** (Modo Deus).
Isso é decidido no servidor — nunca pelo aplicativo.

---

## Segurança (regras do projeto)

1. Nenhuma chave de API dentro do APK. Elas ficam em `backend/.env`.
2. Nenhuma regra de permissão no aplicativo. O app só **mostra ou esconde**
   telas; o servidor **autoriza** cada chamada.
3. `.env`, `*.keystore`, `*.jks` e `google-services.json` estão no `.gitignore`.
4. SHA-1 do certificado só será cadastrado no Firebase quando existir um APK
   assinado — não se inventa SHA-1.

---

## Próximos passos

1. **Compilar o esqueleto** (`assembleDebug`) e corrigir o que aparecer.
2. **V2**: chat real pelo backend (streaming) + seletor de modelos do servidor.
3. **V3**: Firebase Auth + Google Sign-In + SHA-1 do APK assinado.
4. **V4→V10**: histórico no aparelho, arquivos, visão, web, voz, imagens, memória.
