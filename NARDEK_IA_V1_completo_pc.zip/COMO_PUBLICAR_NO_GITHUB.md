# Como publicar a NARDEK IA no GitHub e gerar o APK

Guia direto, feito para quem está **pelo celular**, mas com o caminho de
computador também. Siga na ordem.

- Repositório: `maykryan50-cloud/NARDEK-IA` (branch `main`)
- Compilação: **GitHub Actions** (na nuvem) — não gasta a memória do celular
- Resultado: APK em **Actions → execução → Artifacts**

---

## Antes de começar: o que NÃO vai para o GitHub

O `.gitignore` do projeto já bloqueia (testado):

| Arquivo | Por quê |
|---|---|
| `backend/.env` | contém `SECRET_KEY` e a chave do provedor de IA |
| `app/google-services.json` | configuração do seu projeto Firebase |
| `*.jks` / `*.keystore` | chave de assinatura do app (perder = perder o app) |
| `local.properties` | caminho local do SDK |
| `build/`, `.gradle/`, `__pycache__/` | lixo de compilação |

> Se algum dia o GitHub mostrar um desses arquivos na lista de commits, **pare**
> e me avise: significa que o `.gitignore` precisa de ajuste.

---

## CAMINHO A — pelo celular (2 arquivos para subir)

### Passo 1 — criar o arquivo do robô (o "workflow")

1. Abra o repositório no navegador do celular:
   `https://github.com/maykryan50-cloud/NARDEK-IA`
2. Toque em **Add file** → **Create new file**
3. No campo do nome, digite exatamente (as barras criam as pastas sozinhas):

   ```
   .github/workflows/apk.yml
   ```
4. Apague o conteúdo de exemplo e **cole** o conteúdo do arquivo
   `NARDEK_apk_workflow.yml` (te enviei junto no workspace).
5. Toque em **Commit changes** → **Commit changes**.
   (pode commitar direto na `main`)

   > Esse commit **não** dispara o build (o robô só reage ao ZIP). É esperado
   > a aba Actions continuar vazia até o Passo 2.

### Passo 2 — subir o projeto

1. Na página do repositório: **Add file** → **Upload files**
2. Escolha o arquivo **`NARDEK_IA_V1_repo_upload.zip`** (te enviei no workspace)
3. Toque em **Commit changes**.

> Ao commitar esse ZIP, o robô já dispara automaticamente: ele descompacta o
> projeto dentro do repositório, envia os arquivos e compila o APK. Você não
> precisa fazer mais nada além de esperar.

### Passo 3 — acompanhar e baixar o APK

1. Aba **Actions** → execução **“NARDEK IA — APK”** (a mais recente, com bolinha amarela)
2. Espere ficar **verde** (✔). A primeira compilação leva ~5 a 12 minutos.
3. Role até o fim da página, em **Artifacts**, toque em **nardek-apk-debug**
   (baixa um `.zip`).
4. Descompacte o `.zip` e instale o **`app-debug.apk`** no celular.
   O Android vai pedir para permitir instalação de fontes desconhecidas — é normal.

---

## CAMINHO B — pelo computador (mais rápido, se tiver acesso a um)

```bash
# 1. baixe o ZIP do projeto e descompacte
# 2. entre na pasta e envie
cd NARDEK_IA
git init -b main
git remote add origin https://github.com/maykryan50-cloud/NARDEK-IA.git
git add -A
git commit -m "NARDEK IA V1 — esqueleto modular"
git push -u origin main
```

Se o Git pedir senha, use um **token de acesso pessoal** do GitHub
(Settings → Developer settings → Personal access tokens → Fine-grained),
com permissão `Contents: Read and write` no repositório `NARDEK-IA`.
Use o token no lugar da senha. Depois de enviar, rode o workflow:

1. **Actions** → **NARDEK IA — APK** → **Run workflow** → **Run workflow**
2. Quando ficar verde, baixe em **Artifacts → nardek-apk-debug**

---

## O que o robô faz (passo a passo interno)

1. Baixa o repositório.
2. Se existir um `.zip` na raiz, descompacta e envia os arquivos (só na 1ª vez).
3. Instala JDK 17 e o Android SDK.
4. **Aumenta a memória só no robô** (ele tem ~7 GB): o `gradle.properties` do
   projeto continua limitado a 512 MB, que é o valor certo para o seu celular.
   Os três comandos de ajuste ficam visíveis no log.
5. Compila com `./gradlew :app:assembleDebug --no-daemon --console=plain --stacktrace`.
6. Mostra o **SHA-1** do certificado usado na assinatura.
7. Publica o APK em **Artifacts**.

---

## Ponto importante sobre o SHA-1 e o Firebase (etapa V3)

O APK gerado aqui é assinado com o **certificado de teste do robô**, que ele
recria a cada execução. Isso serve para **instalar e testar o aplicativo**, mas
**não serve para o login com Google**: o Firebase exige um SHA-1 fixo.

Quando chegarmos na V3, vamos:

1. criar **um** certificado de assinatura definitivo (você guarda com segurança);
2. cadastrar o SHA-1 dele no Firebase (`nardek-ia` → Configurações do projeto → seus apps Android);
3. baixar o `google-services.json` novo e guardá-lo **fora** do Git;
4. ligar o login com Google no app.

Não se inventa SHA-1: ele é lido do certificado real.

---

## Se o build falhar

O esqueleto nunca foi compilado ainda — é normal aparecer algum erro de
compilação na primeira execução (tipo de dado, import faltando). O robô mostra
o erro exato no log e **falha de propósito** em vez de fingir sucesso.

Como me mandar o erro:

1. Abra a execução que falhou (bolinha vermelha) → toque no job **build**.
2. Localize o passo vermelho (normalmente **“Compilar o APK de debug”**).
3. Abra, role até o fim e copie as linhas que começam com `e:` (erros do Kotlin)
   ou `> Task ... FAILED`.
4. Me envie esse trecho. Eu corrijo os arquivos e você sobe de novo.

---

## Checklist de segurança (antes de cada envio)

- [ ] Nenhum `.env`, `.jks`, `.keystore` ou `google-services.json` na lista de arquivos alterados
- [ ] `backend/.env` existe **apenas** na sua máquina (ou no servidor), nunca no repositório
- [ ] A chave do provedor de IA só aparece no painel do servidor, nunca em `.kt`, `.xml` ou no APK
- [ ] O papel de proprietário (`OWNER`) está definido em `OWNER_EMAILS` **no servidor**
